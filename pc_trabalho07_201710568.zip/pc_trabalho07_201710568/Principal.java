import java.io.IOException;
import javafx.application.Application;
import static javafx.application.Application.launch;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.stage.Stage;
import controlador.Representacao;
  
/* ***************************************************************
* Autor: Tharcio Thalles Almeida Silva
* Matricula: 201710568
* Inicio: 15 09 2018
* Ultima alteracao: 22 09 2018
* Nome: Leitores e Escritores
* Funcao: O programa ilustra o problema dos LEITORES E ESCRITORES e resolve a condicao de corrida atraves de semaforos
*************************************************************** */

public class Principal extends Application{
  public Scene tela;

  @Override
  public void start(Stage primaryStage) throws IOException{
    Parent fxmlTela = FXMLLoader.load(getClass().getResource("/tela/obra.fxml")); //carregamos o caminho alternativo da tela
    tela = new Scene(fxmlTela); //fazemos com que a cena receba a tela carregada a cima
    primaryStage.setScene(tela); //mudamos o palco para a cena da tela
    primaryStage.show(); // fazemos o palco aparecer para o usuario
  }//fim start

  public static void main(String args[]){
    launch(args);
  }//fim main
}//fim classe