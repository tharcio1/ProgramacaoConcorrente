package controlador;

import java.util.concurrent.Semaphore;

import escritor.Escritor;
import leitor.Leitor;

import java.net.URL;
import java.util.ResourceBundle;
import javafx.fxml.Initializable;
import javafx.scene.image.ImageView;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.fxml.FXML;
import javafx.application.Platform;
import javafx.scene.control.Slider;
import javafx.event.ActionEvent;

public class Representacao implements Initializable{
	
  Semaphore mutex; //controla o acesso a regiao critica
  Semaphore bd;// controla o acesso a base de dados
  public int rc = 0; //numero de processos lendo ou querendo ler

  private Leitor leitor; // declaramos um objeto do tipo Leitor
  private Leitor leitordois; // declaramos um objeto do tipo Leitor
  private Leitor leitortres; // declaramos um objeto do tipo Leitor

  private Escritor escritor; // declaramos um objeto do tipo Escritor
  private Escritor escritordois; // declaramos um objeto do tipo Escritor

  @FXML public ImageView inicial; //tela inicial

  @FXML public ImageView engPensando;
  @FXML public ImageView engEscrevendo;
  @FXML public ImageView engPensando2;
  @FXML public ImageView engEscrevendo2;

  @FXML Button start;

  @FXML public ImageView escritorio1;
  @FXML public ImageView escritorio2;

  @FXML public ImageView pedreiroLendo;
  @FXML public ImageView pedreiroConstruindo;
  @FXML public ImageView pedreiroLendo2;
  @FXML public ImageView pedreiroConstruindo2;
  @FXML public ImageView pedreiroLendo3;
  @FXML public ImageView pedreiroConstruindo3;

  @FXML Slider leitor1;
  @FXML Slider leitor2;
  @FXML Slider leitor3;

  @FXML Slider eng1;
  @FXML Slider eng2;

  @FXML Label pedreLendo;
  @FXML Label pedreConstruindo;
  @FXML Label pedreLendo2;
  @FXML Label pedreConstruindo2;
  @FXML Label pedreLendo3;
  @FXML Label pedreConstruindo3;

  @FXML Label engProjetando;
  @FXML Label engPensandol;
  @FXML Label engProjetando2;
  @FXML Label engPensandol2;

   /* ***********************************************************************
  * Metodo: Construtor
  * Funcao: Todas as instancias dessa classe irah executar o que estah dentro do construtor
  * Parametros: void
  * Retorno: void
  *************************************************************** **********/
  public Representacao(){
    inicial = new ImageView();

    start = new Button();

    engPensando = new ImageView();
    engEscrevendo = new ImageView();
    engProjetando = new Label();
    engPensandol = new Label();
    engPensando2 = new ImageView();
    engEscrevendo2 = new ImageView();
    engProjetando2 = new Label();
    engPensandol2 = new Label();

    pedreiroConstruindo = new ImageView();
    pedreiroLendo = new ImageView();
    pedreLendo = new Label();
    pedreConstruindo = new Label();
    pedreiroConstruindo2 = new ImageView();
    pedreiroLendo2 = new ImageView();
    pedreLendo2 = new Label();
    pedreConstruindo2 = new Label();
    pedreiroConstruindo3 = new ImageView();
    pedreiroLendo3 = new ImageView();
    pedreLendo3 = new Label();
    pedreConstruindo3 = new Label();


    leitor1 = new Slider();
    leitor2 = new Slider();
    leitor3 = new Slider();

    eng1 = new Slider();
    eng2 = new Slider();

    mutex = new Semaphore(1); //iniciamos o semaforo mutex com o valor 1
    bd = new Semaphore(1);    //iniciamos o semaforo bd de banco de dados com o valor 1
    
    leitor = new Leitor("tharcio");
    leitordois = new Leitor("pedro");
    leitortres = new Leitor("joao");

    escritor = new Escritor("thalles");
    escritordois = new Escritor("diego");
  }//Fim construtor

  /* ***************************************************************
  * Metodo: initialize
  * Funcao: vai ser a primeira coisa a ser executada na inicializacao da GUI
  * Parametros: url do tipo URL e rb do tipo ResourceBundle
  * Retorno: void
  *************************************************************** */
  public void initialize(URL url, ResourceBundle rb){
    leitor.setControlador(this);
    leitordois.setControlador(this);
    leitortres.setControlador(this);

    escritor.setControlador(this);
    escritordois.setControlador(this);
  }//Fim initialize

  /* ***********************************************************************
  * Metodo: inicio
  * Funcao: inicia a simulacao
  * Parametros: event do tipo ActionEvent
  * Retorno: void
  *************************************************************** **********/
  public void inicio(ActionEvent event){
    Platform.runLater(() -> {
      start.setVisible(false);
      inicial.setVisible(false);
      leitor.start();
      leitordois.start();
      leitortres.start();
      escritor.start();
      escritordois.start();
    });//Fim Platform
  }//Fim start

  /* ***********************************************************************
  * Metodo: upRC
  * Funcao: incrementar o numero de leitores
  * Parametros: void
  * Retorno: void
  *************************************************************** **********/
  public void upRC(){
    rc += 1; // aumenta o numero de leitores em um
  }//Fim upRC

  /* ***********************************************************************
  * Metodo: upRC
  * Funcao: decrementar o numero de leitores
  * Parametros: void
  * Retorno: void
  *************************************************************** **********/
  public void downRC(){
    rc -= 1; // diminui o numero de leitores em um
  }//Fim upRC

  /* ***********************************************************************
  * Metodo: down
  * Funcao: decrementar os semaforos mutex e bd
  * Parametros: parametro do tipo String
  * Retorno: void
  *************************************************************** **********/
  public void down(String parametro){
    try{
      if(parametro == "mutex"){
        mutex.acquire();
      }//Fim if
      else if(parametro == "bd"){
        bd.acquire();
      }//Fim else if
    }catch(InterruptedException e){
      e.printStackTrace();
    }//Fim catch
  }//Fim down

  /* ***********************************************************************
  * Metodo: up
  * Funcao: incrementar os semaforos mutex e bd
  * Parametros: parametro do tipo String
  * Retorno: void
  *************************************************************** **********/
  public void up(String parametro){
    if(parametro == "mutex"){
      mutex.release();
    }//Fim if
    else if(parametro == "bd"){
      bd.release();
    }//Fim else if
  }//Fim up

  /* ***********************************************************************
  * Metodo: ler
  * Funcao: coloca o pedreiro no estado de lendo
  * Parametros: nome do tipo String
  * Retorno: void
  *************************************************************** **********/
  public void ler(String nome){ 
    try{
      if(nome == "tharcio"){
        int tempoLendo = (int)leitor1.getValue() * 1000;
        trocarImagemLer(pedreConstruindo, pedreiroConstruindo, pedreiroLendo, pedreLendo); // trocar para pedreiro lendo
        Thread.sleep(tempoLendo);
        pedreiroLendo(pedreiroLendo, pedreLendo); // pedreiro lendo fica false
      }//Fim if
      else if(nome == "pedro"){
        int tempoLendo2 =(int)leitor2.getValue() * 1000;
        trocarImagemLer(pedreConstruindo2, pedreiroConstruindo2, pedreiroLendo2, pedreLendo2); // trocar para pedreiro lendo
        Thread.sleep(tempoLendo2);
        pedreiroLendo(pedreiroLendo2, pedreLendo2); // pedreiro lendo fica false
      }//Fim else if
      else if(nome == "joao"){
        int tempoLendo3 = (int)leitor3.getValue() * 1000;
        trocarImagemLer(pedreConstruindo3,pedreiroConstruindo3,pedreiroLendo3,pedreLendo3);// trocar para pedreiro lendo
        Thread.sleep(tempoLendo3);
        pedreiroLendo(pedreiroLendo3, pedreLendo3); // pedreiro lendo fica false
      }//Fim else if
    }catch(InterruptedException e){
      e.printStackTrace();
    }//Fim catch
  }//Fim ler

  /* ***********************************************************************
  * Metodo: trocarImagemLer
  * Funcao: faz com que a imagem e label do pedreiro lendo fique visivel e a imagem dele construindo fique nao visivel
  * Parametros: lbl1 e lbl2 do tipo label img1 e img2 do tipo imageview
  * Retorno: void
  *************************************************************** **********/
  private void trocarImagemLer(Label lbl1, ImageView img1, ImageView img2, Label lbl2) {
  	Platform.runLater(() -> {
  		lbl1.setVisible(false); //pedreiro construindo
      img1.setVisible(false); //pedreiro construindo
      img2.setVisible(true);  //pedreiro lendo
      lbl2.setVisible(true);  //pedreiro lendo
  	});
  }//trocarImagemLer

  /* ***********************************************************************
  * Metodo: pedreiroLendo
  * Funcao: faz com que a imagem e label do pedreiro lendo fique nao visivel 
  * Parametros: lbl do tipo label img do tipo imageview
  * Retorno: void
  *************************************************************** **********/
  private void pedreiroLendo(ImageView img, Label lbl) {
  	Platform.runLater(() -> {
  		img.setVisible(false); //imagem pedreiro lendo
      lbl.setVisible(false); //label pedreiro lendo
  	});//Fim Platform
  }//fim pedreiroLendo

  /* ***********************************************************************
  * Metodo: usarDadosLidos
  * Funcao: faz com que o pedreiro mude para o estado de construindo
  * Parametros: nome do tipo String
  * Retorno: void
  *************************************************************** **********/
  public void usarDadosLidos(String nome){
    try{
      if(nome == "tharcio"){
        int tempoTrabalhando = (int)(8 / (leitor1.getValue())) * 1000;
        pedreiroConstruindo(pedreiroConstruindo,pedreConstruindo); //troca para o pedreiro construindo
        Thread.sleep(tempoTrabalhando);
      }//Fim if
      else if(nome == "pedro"){
        int tempoTrabalhando2 = (int)(8 / (leitor2.getValue())) * 1000;
        pedreiroConstruindo(pedreiroConstruindo2,pedreConstruindo2); //troca para o pedreiro construindo
        Thread.sleep(tempoTrabalhando2);
      }//Fim else if
      else if(nome == "joao"){
        int tempoTrabalhando3 = (int)(8 / (leitor2.getValue())) * 1000;
        pedreiroConstruindo(pedreiroConstruindo3,pedreConstruindo3); //troca para o pedreiro construindo
        Thread.sleep(tempoTrabalhando3);
      }//Fim else if
    }catch(InterruptedException e){
      e.printStackTrace();
    }//Fim catch
  }//Fim usarDadosLidos

  /* ***********************************************************************
  * Metodo: pedreiroConstruindo
  * Funcao: faz com que a imagem e label do pedreiro construindo fique visivel 
  * Parametros: img do tipo imageview e lbl do tipo label
  * Retorno: void
  *************************************************************** **********/
  public void pedreiroConstruindo(ImageView img, Label lbl){
    Platform.runLater(() -> {  
      img.setVisible(true);
      lbl.setVisible(true);
    }); //fim runlatter
  }//Fim pedreiroConstruindo

  /* ***********************************************************************
  * Metodo: pensarSobreInformacao
  * Funcao: faz com que o engenheiro troque para o estado de entregando documentos
  * Parametros: nome do tipo String
  * Retorno: void
  *************************************************************** **********/
  public void pensarSobreInformacao(String nome){
    try{
      if(nome == "thalles"){
        int tempoPensando = (int)eng1.getValue() * 1000;
        pensando(engEscrevendo,engProjetando,escritorio1,engPensando,engPensandol); //troca para o entregando documentos
        Thread.sleep(tempoPensando);
      }//Fim if
      else if(nome == "diego"){
        int tempoPensando2 = (int)eng2.getValue() * 1000;
        pensando(engEscrevendo2,engProjetando2,escritorio2,engPensando2,engPensandol2); //troca para o entregando documentos
        Thread.sleep(tempoPensando2);
      }//Fim else if
    }catch(InterruptedException e){
      e.printStackTrace();
    }//Fim catch
  }//Fim pensarSobreInformacao

  /* ***********************************************************************
  * Metodo: pensando
  * Funcao: faz com que a imagem e label do engenheiro entregando os documentos fique visivel
  * Parametros: engEscrevendo escritorio e pensando do tipo imageview e engProjetando e pensando do tipo label
  * Retorno: void
  *************************************************************** **********/
  public void pensando(ImageView engEscrevendo, Label engProjetando, ImageView escritorio, ImageView pensando, Label pensandol){
    Platform.runLater(() -> {
      engEscrevendo.setVisible(false); //imagem
      engProjetando.setVisible(false); //imagem
      escritorio.setVisible(false);    //imagem
      pensando.setVisible(true);       //imagem
      pensandol.setVisible(true);      //label
    }); //fim runlatter
  }//Fim pensando

  /* ***********************************************************************
  * Metodo: atualizarDados
  * Funcao: faz com que o engenheiro troque para o estado de projetando
  * Parametros: nome do tipo String
  * Retorno: void
  *************************************************************** **********/
  public void atualizarDados(String nome){
    try{
      if(nome == "thalles"){
        int tempoProjetando = (int)(8 / (eng1.getValue())) * 1000;
        engProjetando(escritorio1,engEscrevendo,engProjetando,engPensando,engPensandol); //troca para o engenheiro projetando
        Thread.sleep(tempoProjetando);
      }//Fim if
      else if(nome == "diego"){
        int tempoProjetando2 = (int)(8 / (eng2.getValue())) * 1000;
        engProjetando(escritorio2,engEscrevendo2,engProjetando2,engPensando2,engPensandol2); //troca para o engenheiro projetando
        Thread.sleep(tempoProjetando2);
      }//Fim else if
    }catch(InterruptedException e){
      e.printStackTrace();
    }//Fim catch
  }//Fim atualizarDados 

  /* ***********************************************************************
  * Metodo: engProjetando
  * Funcao: faz com que a imagem e label do engenheiro entregando os documentos fique nao visivel e imagem e label dele projetando fique visivel
  * Parametros: engEscrevendo escritorio e pensando do tipo imageview e engProjetando e pensando do tipo label
  * Retorno: void
  *************************************************************** **********/
  public void engProjetando(ImageView escritorio, ImageView engEscrevendo,Label engProjetando,ImageView pensando, Label pensandol){
    Platform.runLater(() -> {
      pensando.setVisible(false);
      pensandol.setVisible(false);
      escritorio.setVisible(true);
      engEscrevendo.setVisible(true);
      engProjetando.setVisible(true);
    }); //fim runlatter
  }//Fim engProjetando
}//Fim classe Representacao