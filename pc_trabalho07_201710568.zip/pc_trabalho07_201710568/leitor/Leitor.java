package leitor;

import java.lang.Thread;
import controlador.Representacao;
import javafx.application.Platform;

public class Leitor extends Thread{
  Representacao control;
  String nome;

  /* ***********************************************************************
  * Metodo: Construtor
  * Funcao: Todas as instancias dessa classe irah executar o que estah dentro do construtor
  * Parametros: void
  * Retorno: void
  *************************************************************** **********/
  public Leitor(String nome){
    this.nome = nome;
  }//Fim construtor

  /* ***************************************************************
  * Metodo: run
  * Funcao: oque estiver dentro eh executado quando iniciamos a thread do leitor
  * Parametros: void
  * Retorno: void
  *************************************************************** */
  public void run(){
    while(true){
      control.down("mutex"); // obtem acesso exclusivo a regiao critica
      control.upRC(); //aumenta o numero de leitores em 1
      
      if(control.rc == 1){ //se este for o primeiro leitor ele da um down para ter acesso ao banco de dados e nao permitir que um escritor entre mas outros leitores poderao entrar pois so entra no if se o rc for igual a um portanto os outros leitores nao serao bloqueados pois nao entrarao nessa condicao e nao darao entao o down
        control.down("bd");
      }//Fim if

      control.up("mutex"); //libera o acesso exclusivo a regiao critica

      ler(this.nome); //Leitor lendo

      control.down("mutex"); // obtem acesso exclusivo a regiao critica

      control.downRC(); // diminui o numero de leitores em um

      if(control.rc == 0){ //se este for o ultimo leitor o rc sera 0 e liberara o acesso ao banco de dados pois nao existem mais leitores presentes
        control.up("bd");
      }//Fim if

      control.up("mutex"); //libera o acesso exclusivo a regiao critica

      usarDadosLidos(this.nome); // irah usar os dados lidos pode ser por exemplo escrever algo tambem sera o tempo em que esse leitor dormira ate tentar ler os dados novamente

    }//Fim while
  }//Fim run

  /* ***************************************************************
  * Metodo: setControlador
  * Funcao: recebe o controlador para fazer alteracoes na GUI e na classe controladora
  * Parametros: controlador do tipo Representacao
  * Retorno: void
  *************************************************************** */
  public void setControlador(Representacao control){
    this.control = control;
  }//Fim setControlador 

  /* ***************************************************************
  * Metodo: ler
  * Funcao: faz com que o leitor comece a ler
  * Parametros: nome do tipo String
  * Retorno: void
  *************************************************************** */
  public void ler(String nome){
    control.ler(nome);
  }//Fim ler

  /* ***************************************************************
  * Metodo: usadoDadosLidos
  * Funcao: faz com que o leitor comece a construir pois eh um pedreiro
  * Parametros: nome do tipo String
  * Retorno: void
  *************************************************************** */
  public void usarDadosLidos(String nome){
    control.usarDadosLidos(nome);
  }//Fim usarDadosLidos

}//Fim leitor