package escritor;

import java.lang.Thread;
import controlador.Representacao;
import javafx.application.Platform;

public class Escritor extends Thread{
	Representacao control;
  String nome;

   /* ***********************************************************************
  * Metodo: Construtor
  * Funcao: Todas as instancias dessa classe irah executar o que estah dentro do construtor
  * Parametros: void
  * Retorno: void
  *************************************************************** **********/
  public Escritor(String nome){
    this.nome = nome;
  }//Fim construtor

  /* ***************************************************************
  * Metodo: run
  * Funcao: oque estiver dentro eh executado quando iniciamos a thread do escritor
  * Parametros: void
  * Retorno: void
  *************************************************************** */
  public void run(){
    while(true){
      atualizarDados(this.nome); //momento que o escritor ficara projetando ate tentar entregar o projeto regiao nao critica
      control.down("bd"); //tenta obter acesso exclusivo ao notebook caso nao consiga irah para o estado de bloqueado
      pensarSobreInformacao(this.nome); //entrega o projeto - regiao critica
      control.up("bd"); // libera o acesso ao notebook
    }//Fim while
  }//Fim run

  /* ***************************************************************
  * Metodo: setControlador
  * Funcao: recebe o controlador para fazer alteracoes na GUI e na classe controladora
  * Parametros: controlador do tipo Representacao
  * Retorno: void
  *************************************************************** */
  public void setControlador(Representacao control){
    this.control = control;
  }//Fim setControlador

  /* ***************************************************************
  * Metodo: pensarSobreInformacao
  * Funcao: faz com que o engenheiro comece a entregar o seu projeto
  * Parametros: nome do tipo String
  * Retorno: void
  *************************************************************** */
  public void pensarSobreInformacao(String nome){
    control.pensarSobreInformacao(nome);
  }//Fim pensarSobreInformacao

  /* ***************************************************************
  * Metodo: atualizarDados
  * Funcao: faz com que o engenheiro comece a projetar
  * Parametros: nome do tipo String
  * Retorno: void
  *************************************************************** */
  public void atualizarDados(String nome){
    control.atualizarDados(nome);
  }//Fim atualizarDados 

}//Fim Escritor