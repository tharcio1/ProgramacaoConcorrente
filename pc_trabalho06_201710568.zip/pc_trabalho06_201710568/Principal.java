import java.io.IOException;
import javafx.application.Application;
import static javafx.application.Application.launch;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.stage.Stage;
import controlador.Jantar;


/* ***************************************************************
* Autor: Tharcio Thalles Almeida Silva
* Matricula: 201710568
* Inicio: 01/08/2018
* Ultima alteracao: 09/09/2018
* Nome: Jantar Dos Filosofos 
* Funcao: O programa ilustra o problema do Jantar Dos Filosofos
* e resolve a condicao de corrida atraves de semaforos
*************************************************************** */
public class Principal extends Application{
  public static Scene jantar;

  @Override
  public void start(Stage primaryStage ) throws IOException{
    Parent fxmljantar = FXMLLoader.load(getClass().getResource("/telas/jantar.fxml"));

    jantar = new Scene(fxmljantar);

    primaryStage.setScene(jantar);

    primaryStage.show();
  }//fim start

  public static void main(String args[]){
    launch(args);
  }
}//fim classe