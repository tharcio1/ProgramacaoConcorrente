package controlador;

import java.util.concurrent.Semaphore;
import javafx.scene.control.Slider;
import javafx.application.Platform;

public class Filosofo extends Thread{
	Jantar control;
  String nome;
  boolean fome;
  double pensando = 8; //valor inicial para o filosofo comecar pensando
  Garfo esq;
  Garfo dir;
  private Semaphore semaforof1 = new Semaphore(0); // semaforo dos filosofos

  public Filosofo(String nome, Garfo esq, Garfo dir){
    this.nome = nome;
    this.esq = esq;
    this.dir = dir;
    this.fome = false;
  }// fim metodo construtor

  public void run(){
    while(true){
      pensando();

      control.usarGarfo(this); //se chegou aqui eh porque conseguiu acesso a regiao critica entao tenta pegar os garfos

      control.come(this);

      control.soltarGarfos(this);
    }//fim while  
  }//fim run

  
  public void pensando(){
    try{
      if(this.nome == "Filosofo1"){
        pensando = 8;
        pensando = pensando - (control.sliderf1.getValue() / 2); //o valor do pensando diminui conforme aumenta o valor do slider
        Thread.sleep((int)pensando * 1000); // tempo pensando
        control.pensando1.setVisible(false); // pensando fica false pois o filosofo esta com fome
      }//fim if
      else if(this.nome == "Filosofo2"){
        pensando = 8;
        pensando = pensando - (control.sliderf2.getValue() / 2); //o valor do pensando diminui conforme aumenta o valor do slider
        Thread.sleep((int)pensando * 1000); // tempo pensando
        control.pensando2.setVisible(false); // pensando fica false pois o filosofo esta com fome
      }//fim else if
      else if(this.nome == "Filosofo3"){
        pensando = 8;
        pensando = pensando - (control.sliderf3.getValue() / 2); //o valor do pensando diminui conforme aumenta o valor do slider
        Thread.sleep((int)pensando * 1000); // tempo pensando
        control.pensando3.setVisible(false); // pensando fica false pois o filosofo esta com fome
      }//fim else if
      else if(this.nome == "Filosofo4"){
        pensando = 8;
        pensando = pensando - (control.sliderf4.getValue() / 2); //o valor do pensando diminui conforme aumenta o valor do slider
        Thread.sleep((int)pensando * 1000); // tempo pensando
        control.pensando4.setVisible(false); // pensando fica false pois o filosofo esta com fome
      }//fim else if
      else if(this.nome == "Filosofo5"){
        pensando = 8;
        pensando = pensando - (control.sliderf5.getValue() / 2); //o valor do pensando diminui conforme aumenta o valor do slider
        Thread.sleep((int)pensando * 1000); // tempo pensando
        control.pensando5.setVisible(false); // pensando fica false pois o filosofo esta com fome
      }//fim else if
    }catch(InterruptedException e){
      e.printStackTrace();
    }//fim catch
  }// fim pensando

  /* ***************************************************************
  * Metodo: setControlador
  * Funcao: recebe o controlador para fazer alteracoes na GUI
  * Parametros: controlador do tipo jantar j
  * Retorno: void
  *************************************************************** */
  public void setControlador(Jantar j){
    control = j;
  }//fim do metodo setControlador

  public void upSemaforo(){
    semaforof1.release();
  }//fim upSemaforo

  public void downSemaforo(){
    try{
      semaforof1.acquire();
    }catch(InterruptedException e){
      e.printStackTrace();
    }//fim catch
  }//fim upSemaforo

  public String getNome(){
    return this.nome;
  }//fim getNome

  public void setFome(boolean tf){
    this.fome = tf;
    if(this.nome == "Filosofo1"){
      control.comfome1.setVisible(fome);
    }//fim if
    else if(this.nome == "Filosofo2"){
      control.comfome2.setVisible(fome);
    }//fim else if
    else if(this.nome == "Filosofo3"){
      control.comfome3.setVisible(fome);
    }//fim else if
    else if(this.nome == "Filosofo4"){
      control.comfome4.setVisible(fome);
    }//fim else if
    else if(this.nome == "Filosofo5"){
      control.comfome5.setVisible(fome);
    }//fim else if
  }//fim setFome

  public boolean getFome(){
    return this.fome;
  }//fim getFome
}//fim classe