package controlador;

import java.net.URL;
import java.util.ResourceBundle;
import java.lang.Thread;
import javafx.fxml.Initializable;
import javafx.fxml.FXML;
import javafx.scene.image.ImageView;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.event.ActionEvent;
import javafx.application.Platform;
import java.lang.Thread;
import javafx.event.ActionEvent;
import javafx.application.Platform;
import javafx.scene.media.AudioClip;
import java.util.concurrent.Semaphore;
import javafx.scene.control.Slider;

public class Jantar implements Initializable{
	@FXML ImageView garfo1; //imagens dos garfos
  @FXML ImageView garfo2; //imagens dos garfos
 	@FXML ImageView garfo3; //imagens dos garfos
  @FXML ImageView garfo4; //imagens dos garfos
  @FXML ImageView garfo5; //imagens dos garfos

  @FXML ImageView fil1comendo; //filosofo comendo
  @FXML ImageView fil2comendo; //filosofo comendo
  @FXML ImageView fil3comendo; //filosofo comendo
  @FXML ImageView fil4comendo; //filosofo comendo
  @FXML ImageView fil5comendo; //filosofo comendo
  
  @FXML ImageView pensando1; //filosofo pensando
  @FXML ImageView pensando2; //filosofo pensando
  @FXML ImageView pensando3; //filosofo pensando
  @FXML ImageView pensando4; //filosofo pensando
  @FXML ImageView pensando5; //filosofo pensando

  @FXML ImageView comfome1; // estado de fome do filosofo 1
  @FXML ImageView comfome2; // estado de fome do filosofo 2
  @FXML ImageView comfome3; // estado de fome do filosofo 3
  @FXML ImageView comfome4; // estado de fome do filosofo 4
  @FXML ImageView comfome5; // estado de fome do filosofo 5

  @FXML ImageView sushi1; //comida do filosofo 1
  @FXML ImageView sushi2; //comida do filosofo 2
  @FXML ImageView sushi3; //comida do filosofo 3
  @FXML ImageView sushi4; //comida do filosofo 4
  @FXML ImageView sushi5; //comida do filosofo 5

  @FXML Slider sliderf1; // controle do pensando e do comendo
  @FXML Slider sliderf2; // controle do pensando e do comendo
  @FXML Slider sliderf3; // controle do pensando e do comendo
  @FXML Slider sliderf4; // controle do pensando e do comendo
  @FXML Slider sliderf5; // controle do pensando e do comendo

  public static Garfo garfo1c; //controle do garfo
  public static Garfo garfo2c; //controle do garfo
  public static Garfo garfo3c; //controle do garfo
  public static Garfo garfo4c; //controle do garfo 
  public static Garfo garfo5c; //controle do garfo
  
  public static Filosofo filosofo1;  //thread do filosofo um
  public static Filosofo filosofo2; //thread do filosofo dois
  public static Filosofo filosofo3; //thread do filosofo tres
  public static Filosofo filosofo4; //thread do filosofo quatro
  public static Filosofo filosofo5; //thread do filosofo cinco

  static Semaphore mutex = new Semaphore(1);

  private int valordoslider; //variavel que recebera o valor do slider

  /* ***********************************************************************
  * Metodo: Construtor
  * Funcao: Toda instancia da classe executa o que esta dentro do construtor
  * Parametros: void
  * Retorno: void
  *************************************************************** **********/
  public Jantar(){
    garfo1 = new ImageView();
    garfo2 = new ImageView();
    garfo3 = new ImageView();
    garfo4 = new ImageView();
    garfo5 = new ImageView();

    sushi1 = new ImageView();
    sushi2 = new ImageView();
    sushi3 = new ImageView();
    sushi4 = new ImageView();
    sushi5 = new ImageView();

    comfome1 = new ImageView();
    comfome2 = new ImageView();
    comfome3 = new ImageView();
    comfome4 = new ImageView();
    comfome5 = new ImageView();

    sliderf1 = new Slider();
    sliderf2 = new Slider();
    sliderf3 = new Slider();
    sliderf4 = new Slider();
    sliderf5 = new Slider();

    fil1comendo = new ImageView();
    fil2comendo = new ImageView();
    fil3comendo = new ImageView();
    fil4comendo = new ImageView();
    fil5comendo = new ImageView();

    pensando1 = new ImageView();
    pensando2 = new ImageView();
    pensando3 = new ImageView();
    pensando4 = new ImageView();
    pensando5 = new ImageView();

    garfo1c  = new Garfo();
    garfo2c  = new Garfo();
    garfo3c  = new Garfo();
    garfo4c  = new Garfo();
    garfo5c  = new Garfo();

    filosofo1 = new Filosofo("Filosofo1",garfo1c,garfo2c);
    filosofo2 = new Filosofo("Filosofo2",garfo2c,garfo3c);
    filosofo3 = new Filosofo("Filosofo3",garfo3c,garfo4c);
    filosofo4 = new Filosofo("Filosofo4",garfo4c,garfo5c);
    filosofo5 = new Filosofo("Filosofo5",garfo5c,garfo1c);
  }//fim construtor

  /* ***************************************************************
  * Metodo: initialize
  * Funcao: vai ser a primeira coisa a ser executada na inicializacao da GUI
  * Parametros: url do tipo URL e rb do tipo ResourceBundle
  * Retorno: void
  *************************************************************** */
  @Override
  public void initialize(URL url, ResourceBundle rb){
    filosofo1.setControlador(this);
    filosofo2.setControlador(this);
    filosofo3.setControlador(this);
    filosofo4.setControlador(this);
    filosofo5.setControlador(this);

    filosofo1.start(); //start na thread do filosofo 1
    filosofo2.start(); //start na thread do filosofo 2
    filosofo3.start(); //start na thread do filosofo 3
    filosofo4.start(); //start na thread do filosofo 4
    filosofo5.start(); //start na thread do filosofo 5
  }//fim initialize

  /* ***************************************************************
  * Metodo: come
  * Funcao: coloca o filosofo no estado de comer
  * Parametros: nome do filosofo e os garfos que serao utilizados por ele para comer
  * no caso o garfo da esquerda e o garfo da direita
  * Retorno: void
  *************************************************************** */
  public void come(Filosofo f){//aqui ira passar o valor do slider e tera uma variavel recebendo   
    if(f.nome == "Filosofo1"){
      valordoslider = (int)sliderf1.getValue() * 1000;
      pensando1.setVisible(false);
      f.setFome(false);
      garfo1.setVisible(false);
      garfo2.setVisible(false);
      sushi1.setVisible(true);
      fil1comendo.setVisible(true);
    }//fim if
    else if(f.nome == "Filosofo2"){ 
      valordoslider = (int)sliderf2.getValue() * 1000;
      pensando2.setVisible(false); 
      f.setFome(false);
      garfo2.setVisible(false);
      garfo3.setVisible(false);
      sushi2.setVisible(true);
      fil2comendo.setVisible(true);
    }//fim elseif
    else if(f.nome == "Filosofo3"){
      valordoslider = (int)sliderf3.getValue() * 1000;
      pensando3.setVisible(false);
      f.setFome(false);
      garfo3.setVisible(false);
      garfo4.setVisible(false);
      sushi3.setVisible(true);
      fil3comendo.setVisible(true);
    }//fim elseif
    else if(f.nome == "Filosofo4"){
      valordoslider = (int)sliderf4.getValue() * 1000;
      pensando4.setVisible(false);
      f.setFome(false); 
      garfo4.setVisible(false);
      garfo5.setVisible(false);
      sushi4.setVisible(true);
      fil4comendo.setVisible(true);
    }//fim elseif
    else if(f.nome == "Filosofo5"){
      valordoslider = (int)sliderf5.getValue() * 1000;
      pensando5.setVisible(false);
      f.setFome(false); 
      garfo5.setVisible(false);
      garfo1.setVisible(false);
      sushi5.setVisible(true);
      fil5comendo.setVisible(true);
    }//fim elseif
    try{
      Thread.sleep(valordoslider); // tempo que o filosofo ficara comendo
    }catch(InterruptedException e){
      e.printStackTrace();
    }//fim catch    
    Platform.runLater(() -> {
      if(f.nome == "Filosofo1"){
        fil1comendo.setVisible(false);
        sushi1.setVisible(false);
        pensando1.setVisible(true);
        garfo1.setVisible(true);
        garfo2.setVisible(true);
        garfo1c.setEstadoGarfo(false);
        garfo2c.setEstadoGarfo(false);
      }//fim if
      else if(f.nome == "Filosofo2"){    
        fil2comendo.setVisible(false);
        sushi2.setVisible(false);
        pensando2.setVisible(true);
        garfo2.setVisible(true);
        garfo3.setVisible(true);
        garfo2c.setEstadoGarfo(false);
        garfo3c.setEstadoGarfo(false);
      }//fim elseif
      else if(f.nome == "Filosofo3"){
        fil3comendo.setVisible(false);
        sushi3.setVisible(false);
        pensando3.setVisible(true);
        garfo3.setVisible(true);
        garfo4.setVisible(true);
        garfo3c.setEstadoGarfo(false);
        garfo4c.setEstadoGarfo(false);
      }//fim elseif
      else if(f.nome == "Filosofo4"){
        fil4comendo.setVisible(false);
        sushi4.setVisible(false);
        pensando4.setVisible(true);
        garfo4.setVisible(true);
        garfo5.setVisible(true);
        garfo4c.setEstadoGarfo(false);
        garfo5c.setEstadoGarfo(false);
      }//fim elseif
      else if(f.nome == "Filosofo5"){
        fil5comendo.setVisible(false);
        sushi5.setVisible(false);
        pensando5.setVisible(true);
        garfo5.setVisible(true);
        garfo1.setVisible(true);
        garfo5c.setEstadoGarfo(false);
        garfo1c.setEstadoGarfo(false);
      }//fim elseif
    }); //fim runlatter
  }//fim come

  /* ***************************************************************
  * Metodo: usarGarfo
  * Funcao: faz mudanças na gui para exibir que o filosofo esta comendo
  * e muda o valor dos garfos utilizados para true para mostrar que eles estao sendo usados
  * Parametros: nome do filosofo e os garfos que serao utilizados por ele para comer
  * no caso o garfo da esquerda e o garfo da direita
  * Retorno: void
  *************************************************************** */
  public void usarGarfo(Filosofo f){
    try{
      f.setFome(true);
      mutex.acquire();
      test(f);
      mutex.release(); //funcao release eh equivalente ao down no caso libera para outro filosofo entrar
      f.downSemaforo(); // filosofo bloqueado se os garfos estao sendo usados
    }catch(InterruptedException e){
      e.printStackTrace();
    }//fim catch
  }//fim usarGarfo

  public boolean soltarGarfos(Filosofo f){
    try{
      mutex.acquire();
      if(f.nome == "Filosofo1"){
        f.setFome(false);
        if(garfo5c.getEstadoGarfo() == false && filosofo5.getFome() == true){
          garfo5c.setEstadoGarfo(true);
          garfo1c.setEstadoGarfo(true);
          filosofo5.upSemaforo();
        }//fim if-if
        if(garfo3c.getEstadoGarfo() == false && filosofo2.getFome() == true){
          garfo2c.setEstadoGarfo(true);
          garfo3c.setEstadoGarfo(true);
          filosofo2.upSemaforo();
        }//fim if-if
      }//fim if
      else if(f.nome == "Filosofo2"){
        f.setFome(false);
        if(garfo4c.getEstadoGarfo() == false && filosofo3.getFome() == true){
          garfo3c.setEstadoGarfo(true);
          garfo4c.setEstadoGarfo(true);
          filosofo3.upSemaforo();
        }//fim if-if
        if(garfo1c.getEstadoGarfo() == false  && filosofo1.getFome() == true){
          garfo1c.setEstadoGarfo(true);
          garfo2c.setEstadoGarfo(true);
          filosofo1.upSemaforo();
        }//fim if-if
      }//fim else if
      else if(f.nome == "Filosofo3"){
        f.setFome(false);
        if(garfo5c.getEstadoGarfo() == false && filosofo4.getFome() == true){
          garfo5c.setEstadoGarfo(true);
          garfo4c.setEstadoGarfo(true);
          filosofo4.upSemaforo();
        }//fim if-if
        if(garfo2c.getEstadoGarfo() == false && filosofo2.getFome() == true){
          garfo2c.setEstadoGarfo(true);
          garfo3c.setEstadoGarfo(true);
          filosofo2.upSemaforo();
        }//fim if-if
      }//fim else if
      else if(f.nome == "Filosofo4"){
        f.setFome(false);
        if(garfo1c.getEstadoGarfo() == false && filosofo5.getFome() == true){
          garfo5c.setEstadoGarfo(true);
          garfo1c.setEstadoGarfo(true);
          filosofo5.upSemaforo();
        }//fim if-if
        if(garfo3c.getEstadoGarfo() == false && filosofo3.getFome() == true){
          garfo3c.setEstadoGarfo(true);
          garfo4c.setEstadoGarfo(true);
          filosofo3.upSemaforo();
        }//fim if-if
      }//fim else if
      else if(f.nome == "Filosofo5"){
        f.setFome(false);
        if(garfo2c.getEstadoGarfo() == false && filosofo1.getFome() == true){
          garfo1c.setEstadoGarfo(true);
          garfo2c.setEstadoGarfo(true);
          filosofo1.upSemaforo();
        }//fim if-if
        if(garfo4c.getEstadoGarfo() == false && filosofo4.getFome() == true){
          garfo5c.setEstadoGarfo(true);
          garfo4c.setEstadoGarfo(true);
          filosofo4.upSemaforo();
        }//fim if-if
      }//fim else if
      mutex.release();
    }catch(InterruptedException e){
      e.printStackTrace();
    }//fim catch
    return true;
  }//fim soltarGarfos

  public void test(Filosofo f){
    if(f.esq.getEstadoGarfo() == false && f.dir.getEstadoGarfo() == false){
      f.esq.setEstadoGarfo(true);
      f.dir.setEstadoGarfo(true);
      f.upSemaforo();
    }//fim if  
  }// fim test
}//fim classe