package controlador;

import javafx.scene.image.ImageView;

public class Garfo extends Thread{
  Jantar control;

  public int numGarfo = 1; // identificador do garfo
  private boolean estadoGarfo; // nos diz se o grafo esta sendo usado ou nao

  /* ***************************************************************
  * Metodo: Construtor
  * Funcao: Toda instancia da classe executa o que esta dentro do construtor
  * Parametros: void
  * Retorno: void
  *************************************************************** */
  public Garfo(){
    estadoGarfo = false; //desocupado
  }//fim construtor

  public boolean getEstadoGarfo(){
    return this.estadoGarfo;
  }//fim getEstadoGarfo

  public void setEstadoGarfo(boolean estado){
    this.estadoGarfo = estado;
  }//fim setEstadoGarfo
}//fim classe