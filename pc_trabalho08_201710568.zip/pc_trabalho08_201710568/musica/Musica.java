package musica;

import controlador.Controlador;

public class Musica extends Thread{
	Controlador control;
  public void run(){
    while(true){
      control.tocarMusica();
      try{
        sleep(40000);
      }catch(InterruptedException e){
        e.printStackTrace();
      }//Fim catch
    }//Fim while
  }//Fim run

  public void setControlador(Controlador control){
    this.control = control;
  }
}//Fim musica