package cliente;

import controlador.Controlador;

public class Cliente extends Thread{
  Controlador control;
  String nome;
  public Cliente(String nome){
    this.nome = nome;
  }//Fim construtor

  public void run(){
    while(true){
      System.out.println("entrei: " + nome); //apagar
      andar();
      control.down("mutex");
      if(control.espera < control.cadeiras){
        control.up("espera");
        control.up("mutex");
        andar2();
        control.up("cliente");
        System.out.println("Vou tentar cortar meu cabelo - cliente: " + nome); //apagar
        System.out.println(""); //apagar
        control.down("barbeiro");
        corteMeuCabelo(); //vai ate a cadeira e senta nela
        try{
          Thread.sleep((int)control.entradaDeClientes.getValue() * 1000); //slider entradaDeClientes
        }catch(InterruptedException e){
          e.printStackTrace();
        }//Fim catch
      }//Fim if
      else{
        control.up("mutex");
        sair();//sair do estabelecimento
        try{
          Thread.sleep((int)control.entradaDeClientes.getValue() * 1000); //slider entradaDeClientes
        }catch(InterruptedException e){
          e.printStackTrace();
        }//Fim catch
      }//fim else
    }//Fim while
  }//Fim metodo run

  public void setControlador(Controlador control){
    this.control = control;
  }//Fim setControlador

  public void corteMeuCabelo(){ 
    System.out.println("");
    System.out.println("estou sentado na cadeira para cortar meu cabelo - cliente: " + nome);
    control.corteMeuCabelo(this.nome);
  }//Fim corteMeuCabelo

  public void andar(){
    control.percorrerT1(this.nome);
  }//Fim andar

  public void andar2(){
    control.percorrerT2(this.nome);
  }//Fim andar2

  public void sair(){
    control.sair(this.nome);
  }//Fim sair

}//Fim classe