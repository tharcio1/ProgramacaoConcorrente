package barbeiro;

import controlador.Controlador;

public class Barbeiro extends Thread{
	Controlador control;

  public void run(){
    while(true){
      control.serAbencoado(); // equivalente a dormir
      control.down("cliente");
      control.down("mutex");
      control.down("espera");
      control.up("barbeiro");
      control.up("mutex");
      cortarCabelo();  //corta o cabelo  
    }//Fim while
  }//Fim run

  public void setControlador(Controlador control){
    this.control = control;
  }//Fim setControlador

  public void cortarCabelo(){
    try{
      control.exorcizar();
      Thread.sleep((int)control.tempoCortando.getValue() * 1000);//slider tempoCortando
    }catch(InterruptedException e){
      e.printStackTrace();
    }//Fim catch
  }//fim cortarCabelo

}//Fim classe