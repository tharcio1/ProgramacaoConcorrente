package controlador;

import java.util.concurrent.Semaphore;
import java.net.URL;
import java.util.ResourceBundle;
import javafx.fxml.Initializable;
import javafx.scene.image.ImageView;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.application.Platform;
import javafx.fxml.FXML;
import javafx.application.Platform;
import javafx.scene.control.Slider;
import barbeiro.Barbeiro;
import cliente.Cliente;
import musica.Musica;
import javafx.scene.media.AudioClip;

public class Controlador implements Initializable{
	public int cadeiras = 5; //Cadeiras disponiveis
  public int espera = 0; //Clientes esperando para serem atendidos

  Semaphore cliente; // semaforo que controla se o barbeiro irah dormir ou nao
  Semaphore barbeiro; // semaforo utilizado pelo cliente para verificar se o barbeiro estah disponivel para cortar o cabelo
  Semaphore mutex; // semaforo que protege a variavel espera
  Semaphore cadeiraSem; // protege a variavel cadeira
  
  Barbeiro barbeiro1;
  Cliente cliente1;
  Cliente cliente2;
  Cliente cliente3;
  Cliente cliente4;
  Cliente cliente5;
  Cliente cliente6;
  Cliente cliente7;
  Cliente cliente8;
  Musica musicaClasse;

  URL url2;
  AudioClip musica;

  @FXML public ImageView cliente1img;
  @FXML public ImageView sentandostk1;
  @FXML public ImageView sentadostk1;
  @FXML public ImageView endemoniado;
  @FXML public ImageView clienteSaindo;

  @FXML public ImageView cliente2img;
  @FXML public ImageView sentandostk2;
  @FXML public ImageView sentadostk2;
  @FXML public ImageView endemoniado2;
  @FXML public ImageView clienteSaindo2;

  @FXML public ImageView cliente3img;
  @FXML public ImageView sentandostk3;
  @FXML public ImageView sentadostk3;
  @FXML public ImageView endemoniado3;
  @FXML public ImageView clienteSaindo3;

  @FXML public ImageView cliente4img;
  @FXML public ImageView sentandostk4;
  @FXML public ImageView sentadostk4;
  @FXML public ImageView endemoniado4;
  @FXML public ImageView clienteSaindo4;

  @FXML public ImageView cliente5img;
  @FXML public ImageView sentandostk5;
  @FXML public ImageView sentadostk5;
  @FXML public ImageView endemoniado5;
  @FXML public ImageView clienteSaindo5;

  @FXML public ImageView cliente6img;
  @FXML public ImageView sentandostk6;
  @FXML public ImageView sentadostk6;
  @FXML public ImageView endemoniado6;
  @FXML public ImageView clienteSaindo6;
  
  @FXML public ImageView cliente7img;
  @FXML public ImageView sentandostk7;
  @FXML public ImageView sentadostk7;
  @FXML public ImageView endemoniado7;
  @FXML public ImageView clienteSaindo7;

  @FXML public ImageView cliente8img;
  @FXML public ImageView sentandostk8;
  @FXML public ImageView sentadostk8;
  @FXML public ImageView endemoniado8;
  @FXML public ImageView clienteSaindo8;

  @FXML public ImageView pastorOrando;
  @FXML public ImageView pastorSaldando;
  @FXML public ImageView deusAbencoando;

  @FXML public Slider entradaDeClientes;
  @FXML public Slider tempoCortando;

  private double posicaoxcl1;
  private double posicaoxcl2;
  private double posicaoxcl3;
  private double posicaoxcl4;
  private double posicaoxcl5;
  private double posicaoxcl6;
  private double posicaoxcl7;
  private double posicaoxcl8;

  private boolean cadeira[] = new boolean[5];


  /* ***************************************************************
  * Metodo: initialize
  * Funcao: vai ser a primeira coisa a ser executada na inicializacao da GUI
  * Parametros: url do tipo URL e rb do tipo ResourceBundle
  * Retorno: void
  *************************************************************** */
  public void initialize(URL url, ResourceBundle rb){
    barbeiro1.setControlador(this);
    cliente1.setControlador(this);
    cliente2.setControlador(this);
    cliente3.setControlador(this);
    cliente4.setControlador(this);
    cliente5.setControlador(this);
    cliente6.setControlador(this);
    cliente7.setControlador(this);
    cliente8.setControlador(this);
    musicaClasse.setControlador(this);

    barbeiro1.start();
    cliente1.start();
    cliente2.start();
    cliente3.start();
    cliente4.start();
    cliente5.start();
    cliente6.start();
    cliente7.start();
    cliente8.start();
    musicaClasse.start();

  }//Fim initialize

  /* ***********************************************************************
  * Metodo: Construtor
  * Funcao: Todas as instancias dessa classe irah executar o que estah dentro do construtor
  * Parametros: void
  * Retorno: void
  *************************************************************** **********/
  public Controlador(){
    cliente = new Semaphore(0);
    barbeiro = new Semaphore(0);
    mutex = new Semaphore(1);
    cadeiraSem = new Semaphore(1);

    barbeiro1 = new Barbeiro();
    cliente1 = new Cliente("Tharcio");
    cliente2 = new Cliente("Diego");
    cliente3 = new Cliente("Joao");
    cliente4 = new Cliente("Kleber");
    cliente5 = new Cliente("Felipe");
    cliente6 = new Cliente("Matheus");
    cliente7 = new Cliente("Rick");
    cliente8 = new Cliente("Morty");
    musicaClasse = new Musica();

    url2 = getClass().getClassLoader().getResource("tela/sons/musica.mp3");
    musica = new AudioClip(url2.toExternalForm());

    cliente1img = new ImageView();
    sentandostk1 = new ImageView();
    sentadostk1 = new ImageView();
    endemoniado = new ImageView();
    clienteSaindo = new ImageView();

    cliente2img = new ImageView();
    sentandostk2 = new ImageView();
    sentadostk2 = new ImageView();
    endemoniado2 = new ImageView();
    clienteSaindo2 = new ImageView();

    cliente3img = new ImageView();
    sentandostk3 = new ImageView();
    sentadostk3 = new ImageView();
    endemoniado3 = new ImageView();
    clienteSaindo3 = new ImageView();

    cliente4img = new ImageView();
    sentandostk4 = new ImageView();
    sentadostk4 = new ImageView();
    endemoniado4 = new ImageView();
    clienteSaindo4 = new ImageView();

    cliente5img = new ImageView();
    sentandostk5 = new ImageView();
    sentadostk5 = new ImageView();
    endemoniado5 = new ImageView();
    clienteSaindo5 = new ImageView();

    cliente6img = new ImageView();
    sentandostk6 = new ImageView();
    sentadostk6 = new ImageView();
    endemoniado6 = new ImageView();
    clienteSaindo6 = new ImageView();

    cliente7img = new ImageView();
    sentandostk7 = new ImageView();
    sentadostk7 = new ImageView();
    endemoniado7 = new ImageView();
    clienteSaindo7 = new ImageView();

    cliente8img = new ImageView();
    sentandostk8 = new ImageView();
    sentadostk8 = new ImageView();
    endemoniado8 = new ImageView();
    clienteSaindo8 = new ImageView();

    pastorSaldando = new ImageView();
    pastorOrando = new ImageView();
    deusAbencoando = new ImageView();

    entradaDeClientes = new Slider();
    tempoCortando = new Slider();

    posicaoxcl1 = cliente1img.getLayoutX();

    posicaoxcl2 = cliente2img.getLayoutX();

    posicaoxcl3 = cliente3img.getLayoutX();

    posicaoxcl4 = cliente4img.getLayoutX();

    posicaoxcl5 = cliente5img.getLayoutX();

    posicaoxcl6 = cliente6img.getLayoutX();

    posicaoxcl7 = cliente7img.getLayoutX();

    posicaoxcl8 = cliente8img.getLayoutX();

    for(int i = 0; i < 5; i++){
      cadeira[i] = false;
    }//Fim for
  }//Fim construtor controlador

  public void down(String parametro){
    try{
      if(parametro == "cliente"){
        cliente.acquire();
      }//Fim if
      else if(parametro == "mutex"){
        mutex.acquire();
      }//Fim else if
      else if(parametro == "espera"){
        espera -= 1;
      }//Fim else if
      else if(parametro == "barbeiro"){
        barbeiro.acquire();
      }//Fim else if
    }catch(InterruptedException e){
      e.printStackTrace();
    }//Fim catch
  }//Fim down

  public void up(String parametro){
    if(parametro == "barbeiro"){
      barbeiro.release();
    }//Fim if
    else if(parametro == "mutex"){
      mutex.release();
    }//Fim else if
    else if(parametro == "espera"){
      espera += 1;
    }//Fim else if
    else if(parametro == "cliente"){
      cliente.release();
    }//Fim else if
  }//Fim up

  public void sair(String nome){
    if(nome == "Tharcio"){
      vouSair(cliente1img, clienteSaindo, posicaoxcl1);
    }//Fim if
    else if(nome == "Diego"){
      vouSair(cliente2img, clienteSaindo2, posicaoxcl2);
    }//Fim else if
    else if(nome == "Joao"){
      vouSair(cliente3img, clienteSaindo3, posicaoxcl3);
    }//Fim else if
    else if(nome == "Kleber"){
      vouSair(cliente4img, clienteSaindo4, posicaoxcl4);
    }//Fim else if
    else if(nome == "Felipe"){
      vouSair(cliente5img, clienteSaindo5, posicaoxcl5);
    }//Fim else if
    else if(nome == "Matheus"){
      vouSair(cliente6img, clienteSaindo6, posicaoxcl6);
    }//Fim else if
    else if(nome == "Rick"){
      vouSair(cliente7img, clienteSaindo7, posicaoxcl7);
    }//Fim else if
    else if(nome == "Morty"){
      vouSair(cliente8img, clienteSaindo8, posicaoxcl8);
    }//Fim else if
  }//Fim sair

  public void vouSair(ImageView cliente, ImageView clienteSaindo, double posicaoCliente){
    //posicaoCliente = 70.0;
    Platform.runLater(() -> {
      //clienteSaindo.setLayoutX(70.0);
      cliente.setVisible(false);
      cliente.setLayoutX(0);
      //clienteSaindo.setVisible(true);
    });//Fim Platform
    /*while(clienteSaindo.getLayoutX() > 10.0){
      posicaoCliente -= 13;
      saindo(clienteSaindo,posicaoCliente);
    }//Fim while
    clienteSaindo.setVisible(false);*/
  }//Fim sair

  public void saindo(ImageView clienteSaindo, double posicaoCliente){
    Platform.runLater(() -> {
      clienteSaindo.setLayoutX(posicaoCliente);
    });//Fim Platform
  }//Fim saindo

  public void mover(ImageView cliente, double posicaoCliente){
    Platform.runLater(() -> {
      cliente.setVisible(true);
      cliente.setLayoutX(posicaoCliente);
    });//Fim Platform
  }//Fim mover

  public void andar(double posicaoCliente, ImageView cliente){
    posicaoCliente = cliente.getLayoutX();
    while(cliente.getLayoutX() < 70.0){
      posicaoCliente += 10;
      mover(cliente, posicaoCliente);
      try{
       Thread.sleep(700);
      }catch(InterruptedException e){
        e.printStackTrace();
      }//fim catch
    }//fim while
  }//Fim andar

  public void percorrerT1(String nome){
    if(nome == "Tharcio"){
      andar(posicaoxcl1, cliente1img);
    }//Fim if
    else if(nome == "Diego"){
      andar(posicaoxcl2, cliente2img);
    }//Fim else if
    else if(nome == "Joao"){
      andar(posicaoxcl3, cliente3img);
    }//Fim else if
    else if(nome == "Kleber"){
      andar(posicaoxcl4, cliente4img);
    }//Fim else if
    else if(nome == "Felipe"){
      andar(posicaoxcl5, cliente5img);
    }//Fim else if
    else if(nome == "Matheus"){
      andar(posicaoxcl6, cliente6img);
    }//Fim else if
    else if(nome == "Rick"){
      andar(posicaoxcl7, cliente7img);
    }//Fim else if
    else if(nome == "Morty"){
      andar(posicaoxcl8, cliente8img);
    }//Fim else if
  }//fim percorrerT1

  public void sentarCadeira(ImageView sentando, ImageView sentado, ImageView cliente){
    Platform.runLater(() -> {
      sentando.setLayoutX(cliente.getLayoutX());
      sentado.setLayoutX(cliente.getLayoutX());
      cliente.setVisible(false);
      sentando.setVisible(true);
    });//Fim Platform
    try{
      Thread.sleep(700);
    }catch(InterruptedException e){
      e.printStackTrace();
    }//fim catch
    Platform.runLater(() -> {
      sentando.setVisible(false);
      sentado.setVisible(true);
    });//Fim Platform
  }//Fim sentarCadeira

  public void andar2(double posicaoCliente, ImageView cliente, ImageView sentando, ImageView sentado){
    posicaoCliente = cliente.getLayoutX();
    try{
      while(true){
        posicaoCliente += 5;
        mover(cliente, posicaoCliente);
        if(posicaoCliente == 140.0 || posicaoCliente == 195.0 || posicaoCliente == 255.0 || posicaoCliente == 300.0 || posicaoCliente == 350.0){
          //cadeiraSem.acquire(); // acessar se a cadeira esta vazia ou nao
          if(posicaoCliente == 140.0 && cadeira[0] == false){
            cadeira[0] = true;
            sentarCadeira(sentando, sentado, cliente);
            //cadeiraSem.release();
            break;
          }//fim if
          else if(posicaoCliente == 195.0 && cadeira[1] == false){
            cadeira[1] = true;
            sentarCadeira(sentando, sentado, cliente);
            //cadeiraSem.release();
            break;
          }//Fim else if
          else if(posicaoCliente == 255.0 && cadeira[2] == false){
            cadeira[2] = true;
            sentarCadeira(sentando, sentado, cliente);
            //cadeiraSem.release();
            break;
          }//Fim else if
          else if(posicaoCliente == 300.0 && cadeira[3] == false){
            cadeira[3] = true;
            sentarCadeira(sentando, sentado, cliente);
            //cadeiraSem.release();
            break;
          }//Fim else if
          else if(posicaoCliente == 350.0 && cadeira[4] == false){
            cadeira[4] = true;
            sentarCadeira(sentando, sentado, cliente);
            //cadeiraSem.release();
            break;
          }//Fim else if
        }//Fim if
        Thread.sleep(200);
      }//fim while
    }catch(InterruptedException e){
      e.printStackTrace();
    }//fim catch
  }//Fim andar2

  public void percorrerT2(String nome){
    if(nome == "Tharcio"){
      andar2(posicaoxcl1,cliente1img,sentandostk1,sentadostk1);
    }//Fim if
    else if(nome == "Diego"){
      andar2(posicaoxcl2,cliente2img,sentandostk2,sentadostk2);
    }//Fim else if
    else if(nome == "Joao"){
      andar2(posicaoxcl3,cliente3img,sentandostk3,sentadostk3);
    }//Fim else if
    else if(nome == "Kleber"){
      andar2(posicaoxcl4,cliente4img,sentandostk4,sentadostk4);
    }//Fim else if
    else if(nome == "Felipe"){
      andar2(posicaoxcl5,cliente5img,sentandostk5,sentadostk5);
    }//Fim else if
    else if(nome == "Matheus"){
      andar2(posicaoxcl6,cliente6img,sentandostk6,sentadostk6);
    }//Fim else if
    else if(nome == "Rick"){
      andar2(posicaoxcl7,cliente7img,sentandostk7,sentadostk7);
    }//Fim else if
    else if(nome == "Morty"){
      andar2(posicaoxcl8,cliente8img,sentandostk8,sentadostk8);
    }//Fim else if
  }//fim percorrerT2

  public void corteMeuCabelo(String nome){
    if(nome == "Tharcio"){
      cortandoCabelo(sentadostk1, cliente1img, endemoniado);
    }//Fim if
    else if(nome == "Diego"){
      cortandoCabelo(sentadostk2, cliente2img, endemoniado2);
    }//Fim else if
    else if(nome == "Joao"){
      cortandoCabelo(sentadostk3, cliente3img, endemoniado3);
    }//Fim else if
    else if(nome == "Kleber"){
      cortandoCabelo(sentadostk4, cliente4img, endemoniado4);
    }//Fim else if
    else if(nome == "Felipe"){
      cortandoCabelo(sentadostk5, cliente5img, endemoniado5);
    }//Fim else if
    else if(nome == "Matheus"){
      cortandoCabelo(sentadostk6, cliente6img, endemoniado6);
    }//Fim else if
    else if(nome == "Rick"){
      cortandoCabelo(sentadostk7, cliente7img, endemoniado7);
    }//Fim else if
    else if(nome == "Morty"){
      cortandoCabelo(sentadostk8, cliente8img, endemoniado8);
    }//Fim else if
  }//Fim corteMeuCabelo

  /*public void cortandoCabelo(ImageView sentado, ImageView cliente, ImageView sentando, double posicaoCliente){
    posicaoCliente = cliente.getLayoutX();
    sentado.setVisible(false);
    cliente.setVisible(true);
    try{
      while(posicaoCliente < 460){
        System.out.println("dentro de cortar andar " + posicaoCliente);
        posicaoCliente += 10;
        cliente.setLayoutX(posicaoCliente);
        Thread.sleep(400);
        if(posicaoCliente == 460.0){
          sentando.setLayoutX(460);
          sentado.setLayoutX(460);
          cliente.setVisible(false);
          sentando.setVisible(true);
          Thread.sleep(700);
          sentando.setVisible(false);
          sentado.setVisible(true);
          Thread.sleep(3000);
        }//fim if
      }//Fim while
    }catch(InterruptedException e){
      e.printStackTrace();
    }//Fim catch
  }//Fim cortandoCabelo*/

  public void cortandoCabelo(ImageView sentado, ImageView cliente,ImageView endemoniado){
    double posicaoEsp = cliente.getLayoutX();
    try{
      if(posicaoEsp == 140.0){
        cadeira[0] = false; //cliente foi cortar cabelo
      }//fim if
      else if(posicaoEsp == 195.0){
        cadeira[1] = false; //cliente foi cortar cabelo
      }//Fim else
      else if(posicaoEsp == 255.0){
        cadeira[2] = false; //cliente foi cortar cabelo
      }//Fim else
      else if(posicaoEsp == 300.0){
        cadeira[3] = false; //cliente foi cortar cabelo
      }//Fim else
      else if(posicaoEsp == 350.0){
        cadeira[4] = false; //cliente foi cortar cabelo
      }//Fim else
      endemoniar(sentado, endemoniado);
      Thread.sleep((int)tempoCortando.getValue() * 1000); //slider tempoCortando
      desenmoniar(endemoniado, cliente);
    }catch(InterruptedException e){
      e.printStackTrace();
    }//Fim catch
  }//Fim cortandoCabelo

  public void endemoniar(ImageView sentado, ImageView endemoniado){
    Platform.runLater(() -> {
      sentado.setVisible(false);
      endemoniado.setVisible(true);
    });//Fim Platform
  }//Fim endemoniar

  public void desenmoniar(ImageView endemoniado, ImageView cliente){
    Platform.runLater(() -> {
      endemoniado.setVisible(false);
      cliente.setLayoutX(0);
    });//Fim Platform
  }//Fim desenmoniar

  public void serAbencoado(){
    Platform.runLater(() -> {
      pastorOrando.setVisible(false);
      deusAbencoando.setVisible(true);
      pastorSaldando.setVisible(true);
    });//Fim Platform
  }//Fim dormir

  public void exorcizar(){
    Platform.runLater(() -> {
      deusAbencoando.setVisible(false);
      pastorSaldando.setVisible(false);
      pastorOrando.setVisible(true);
    });//Fim Platform
  }//Fim exorcizar

  public void tocarMusica(){
    musica.play();
  }
}//Fim classe Controlador