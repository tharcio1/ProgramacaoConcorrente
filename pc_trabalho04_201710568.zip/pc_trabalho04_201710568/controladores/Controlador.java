package controladores;
import java.io.IOException;
import javafx.application.Application;
import javafx.fxml.FXMLLoader;
import java.net.URL;
import java.util.ResourceBundle;
import javafx.fxml.Initializable;
import javafx.fxml.FXML;
import javafx.scene.image.ImageView;
import java.lang.Thread;
import javafx.event.ActionEvent;
import javafx.application.Platform;

/* ***************************************************************
* Autor: Tharcio Thalles Almeida Silva
* Matricula: 201710568
* Inicio: 05/08/2018
* Ultima alteracao: 12/08/2018
* Nome: Problema do Trem
* Funcao: O programa utiliza de Threads para executar concorrentemente duas classes cada uma representando um carro e a funcao do programa eh fazer com que os carros nao se batam
*************************************************************** */


/*********************************************************************
* Classe: Controlador
* Funcao: controla todas as funcoes da tela incluindo a velocidade do carro vermelho e amarelo
******************************************************************* */
public class Controlador implements Initializable {
  @FXML ImageView carroVermelho;
  @FXML ImageView carroAmarelo;
  
  CarroVermelho cv;
  CarroAmarelo cam;
  public static boolean sinalca = false; // bandeira que representa se o carro amarelo entrou na zona de pista unica
  public static boolean sinalcv = false;// bandeira que representa se o carro vermelho entrou na zona de pista unica
  public static int velocidade = 3; // velocidade minima do carro vermelho
  public static int velocidade2 = 3;// velocidade minima do carro amarelo

  public Controlador(){
    carroVermelho = new ImageView();
    cv = new CarroVermelho(); //instanciando a classe CarroVermelho
    carroAmarelo = new ImageView();
    cv = new CarroVermelho(); //instanciando a classe CarroAmarelo
    cam = new CarroAmarelo();
  }//fim do construtor controlador

  @Override
  public void initialize(URL url, ResourceBundle rb) {
    cv.setControlador(this); //passo o controlador por parametro para a classe CarroVermelho
    cam.setControlador(this);//passo o controlador por parametro para a classe CarroAmarelo
    cam.start(); //inicio a thread do carro amarelo
    cv.start(); //inicio a thread do carro vermelho
  } //fim do initialize
 
  /****************************************************************
  * Metodo: vel1
  * Funcao: acelerar a velocidade do carro vermelho
  * Parametros: event
  * Retorno: void
  ****************************************************************/ 
  @FXML
  public void vel1(ActionEvent event){
    if(velocidade < 12){ //velocidade maxima eh 12
      velocidade += 3;
    }//fim if
  }//fim metodo vel1
  /****************************************************************
  * Metodo: vel2
  * Funcao: frear a velocidade do carro vermelho
  * Parametros: event
  * Retorno: void
  ****************************************************************/ 
  @FXML
  public void vel2(ActionEvent event){
    if(velocidade > 3){ //velocidade minima eh 3
      velocidade -= 3;
    }//fim if
  }//fim metodo vel2

  /****************************************************************
  * Metodo: carroVermelho
  * Funcao: fazer o controle da velocidade e das curvas do carro vermelho
  * Parametros: nao tem parametros
  * Retorno: void
  ****************************************************************/
  public void carroVermelho(){
    double posicaox = carroVermelho.getLayoutX(); //variavel posicaox que sera usada para setar a posicaox do carro vermelho
    double posicaoy = carroVermelho.getLayoutY(); //variavel posicaoy que sera usada para setar a posicaox do carro vermelho
    double rotacao = carroVermelho.getRotate(); //variavel rotacao que sera usada para setar a rotacao do carro vermelho

  /**************************************************************************
  * Funcao: verificar se o carro vermelho esta na posicao correta para andar
  ***************************************************************************/
    if(carroVermelho.getLayoutX() > 130.0){ 
      rotacao = 0;
      carroVermelho.setRotate(rotacao);
      posicaox -= velocidade;
      carroVermelho.setLayoutX(posicaox);
    }//fim if
      
    /*************************************************************************
    * Funcao: verificar se o carro vermelho esta na posicao correta para andar
    **************************************************************************/
    else if(carroVermelho.getLayoutX() <= 138.0 && carroVermelho.getLayoutY() >= 45.0 && carroVermelho.getLayoutY() <= 50.0){
      try{
        rotacao -= 90; //PRIMEIRA CURVA

        posicaox -= 15;
        carroVermelho.setLayoutX(posicaox);
        carroVermelho.setRotate(rotacao); //muda a rotacao do carro vermelho
        while(carroVermelho.getLayoutY() < 535.0){
          posicaoy += velocidade; 
          carroVermelho.setLayoutY(posicaoy);
          Thread.sleep(50);
        }//fim while

        rotacao -= 90; // SEGUNDA CURVA

        carroVermelho.setRotate(rotacao); //muda a rotacao do carro vermelho
        posicaox += 3;
        carroVermelho.setLayoutX(posicaox);
          
        /*************************************************************************
        * Funcao: verificar se o carro vermelho esta na posicao correta para andar
        **************************************************************************/
        if(carroVermelho.getLayoutX() <= 119.0){
          posicaoy = 537.0;
          posicaox = 143.0;
          carroVermelho.setLayoutX(posicaox);
          carroVermelho.setLayoutY(posicaoy);

          /*************************************************************************
          * Funcao: verificar se o carro vermelho esta na posicao correta para andar
          **************************************************************************/
          while(carroVermelho.getLayoutX() < 565.0){
            if(carroVermelho.getLayoutX() == 143.0 && carroVermelho.getLayoutY() == 537.0 && sinalca == false){
              sinalcv = true;
              rotacao = 142;
              carroVermelho.setRotate(rotacao); //sai do obstaculo
              Thread.sleep(800);
              carroVermelho.setLayoutY(500);
              carroVermelho.setRotate(180);
              posicaox += 15;
              carroVermelho.setLayoutX(posicaox);
              while(carroVermelho.getLayoutX() != 280.0){
                posicaox += 2;
                carroVermelho.setLayoutX(posicaox);
                Thread.sleep(50);
              } //fim while
              if(carroVermelho.getLayoutX() == 280.0){  
                carroVermelho.setRotate(212);
                Thread.sleep(800);
                carroVermelho.setLayoutY(537);
                carroVermelho.setRotate(180);
                sinalcv = false;
              }//fim if

            }//fim if
            else{
              while(sinalca == true && carroVermelho.getLayoutX() < 280){
                Thread.sleep(40);
              }//fim while
            }//fim else
            if(carroVermelho.getRotate() == 180){
              posicaox += velocidade;
              carroVermelho.setLayoutX(posicaox);
              Thread.sleep(50);
            } //fim if
          } //fim while
        }//fim if
           
        /*************************************************************************
        * Funcao: verificar se o carro vermelho esta na posicao correta para andar
        **************************************************************************/  
        if(carroVermelho.getLayoutX() >= 565.0){
          rotacao = 90; // TERCEIRA CURVA
              
          carroVermelho.setRotate(rotacao); //altera a rotacao do carro
              
          posicaox += 18;
          carroVermelho.setLayoutX(posicaox);
          while(carroVermelho.getLayoutY() > 78.0){
            posicaoy -= velocidade; 
            carroVermelho.setLayoutY(posicaoy);
            Thread.sleep(50);
          }//fim while
          carroVermelho.setLayoutY(48.0);
        }//fim if
      }//fim do try
      catch(InterruptedException e){
        e.printStackTrace();
      } //fim do catch
    } //fim do if numero 2 
  }//fim do metodo carroVermelho

   /****************************************************************
  * Metodo: velCA
  * Funcao: acelerar a velocidade do carro amarelo
  * Parametros: event
  * Retorno: void
  ****************************************************************/
  @FXML
  public void velCA(ActionEvent event){
    if(velocidade2 < 12){  //velocidade maxima eh 12
      velocidade2 += 3;
    }//fim if
  } //fim do metodo velCA

 /****************************************************************
  * Metodo: velCA2
  * Funcao: frear a velocidade do carro amarelo
  * Parametros: event
  * Retorno: void
  ****************************************************************/
  @FXML
  public void velCA2(ActionEvent event){
    if(velocidade2 > 3){  //velocidade minima eh 3
      velocidade2 -= 3;
    }//fim if
  }//fim do metodo velCA2

  /****************************************************************
  * Metodo: carroAmarelo
  * Funcao: fazer o controle da velocidade e das curvas do carro amarelo
  * Parametros: nao tem parametros
  * Retorno: void
  ****************************************************************/
  public void carroAmarelo(){
    double posicaoxa = carroAmarelo.getLayoutX(); //variavel posicaox que sera usada para setar a posicao X do carro amarelo
    double posicaoya = carroAmarelo.getLayoutY(); //variavel posicaoy que sera usada para setar a posicao Y do carro amarelo
    double rotacaoa = carroAmarelo.getRotate(); //variavel rotacao que sera usada para setar a rotacao do carro amarelo

    /*********************************************************************************************
    * Funcao: verificar se o carro amarelo esta na posicao correta para andar ou trocar de rotacao
    **********************************************************************************************/
    if(carroAmarelo.getLayoutY() < 466 && carroAmarelo.getLayoutX() == 544.0){
      posicaoya += velocidade2;
      carroAmarelo.setLayoutY(posicaoya);
    }//fim do if
            
    /*********************************************************************************************
    * Funcao: verificar se o carro amarelo esta na posicao correta para andar ou trocar de rotacao
    **********************************************************************************************/
    else if(carroAmarelo.getLayoutY() >= 466.0 && carroAmarelo.getLayoutY() <= 478.0  && carroAmarelo.getLayoutX() == 544.0){
      rotacaoa = 90; //   PRIMEIRA CURVA
      carroAmarelo.setRotate(rotacaoa);
      posicaoya = 503;
      carroAmarelo.setLayoutY(posicaoya);
      posicaoya += 1;
      carroAmarelo.setLayoutY(posicaoya);
    } //fim do else if
      
    /*********************************************************************************************
    * Funcao: verificar se o carro amarelo esta na posicao correta para andar ou trocar de rotacao
    **********************************************************************************************/
    else if(carroAmarelo.getLayoutX() >= 175.0 && carroAmarelo.getLayoutY() == 504.0){
      if(carroAmarelo.getLayoutX() > 400.0 && sinalcv == false){
        sinalca = true;
        posicaoxa -= velocidade2;
        carroAmarelo.setLayoutX(posicaoxa);
      }//fim if
      else{
        while(sinalcv == true){
          carroAmarelo.setLayoutX(posicaoxa);
        }//fim while
          
        if(carroAmarelo.getLayoutX() <= 400.0 && carroAmarelo.getLayoutX() >= 175.0 ){
          posicaoxa -= velocidade2;
          carroAmarelo.setLayoutX(posicaoxa); 
        }//fim if
      }//fim else
    }//fim else if
      
    /*********************************************************************************************
    * Funcao: verificar se o carro amarelo esta na posicao correta para andar ou trocar de rotacao
    **********************************************************************************************/
    else if(carroAmarelo.getLayoutX() <= 180.0 && carroAmarelo.getLayoutX() >= 160.0 && carroAmarelo.getLayoutY() == 504.0){
      rotacaoa = -180; //  SEGUNDA CURVA
      carroAmarelo.setRotate(rotacaoa);
      posicaoxa = 154;
      carroAmarelo.setLayoutX(posicaoxa);
      posicaoya = 485;
      carroAmarelo.setLayoutY(posicaoya);
    } //fim else if
      
    /*********************************************************************************************
    * Funcao: verificar se o carro amarelo esta na posicao correta para andar ou trocar de rotacao
    **********************************************************************************************/
    else if(carroAmarelo.getLayoutY() > 113.0 && carroAmarelo.getLayoutX() == 154.0){
      posicaoya -= velocidade2;
      carroAmarelo.setLayoutY(posicaoya);
      sinalca = false;
    } //fim else if

    /*********************************************************************************************
    * Funcao: verificar se o carro amarelo esta na posicao correta para andar ou trocar de rotacao
    **********************************************************************************************/
    else if(carroAmarelo.getLayoutY() >= 101.0 && carroAmarelo.getLayoutY() <= 115.0 && carroAmarelo.getLayoutX() == 154.0){
      rotacaoa = 270; // TERCEIRA CURVA
      carroAmarelo.setRotate(rotacaoa);
      posicaoya = 85;
      posicaoxa = 170;
      carroAmarelo.setLayoutY(posicaoya);
      carroAmarelo.setLayoutX(posicaoxa);
    } //fim else if

    /*********************************************************************************************
    * Funcao: verificar se o carro amarelo esta na posicao correta para andar ou trocar de rotacao
    **********************************************************************************************/
    if(carroAmarelo.getLayoutX() <= 528.0 && carroAmarelo.getLayoutY() == 85.0){
      posicaoxa += velocidade2;
      carroAmarelo.setLayoutX(posicaoxa);
    } //fim else if

    /*********************************************************************************************
    * Funcao: verificar se o carro amarelo esta na posicao correta para andar ou trocar de rotacao
    **********************************************************************************************/
    if(carroAmarelo.getLayoutX() >= 515.0 && carroAmarelo.getLayoutY() == 85.0){
      rotacaoa = 0; // VOLTA PARA A CURVA INICIAL
      carroAmarelo.setRotate(rotacaoa);
      posicaoxa = 544;
      posicaoya = 120;
      carroAmarelo.setLayoutX(posicaoxa);
      carroAmarelo.setLayoutY(posicaoya);
    } //fim if
    }//fim do metodo carroAmarelo
}//fim da classe Controlador