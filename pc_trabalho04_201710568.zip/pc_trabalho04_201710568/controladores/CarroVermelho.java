package controladores;

/* ***************************************************************
* Autor: Tharcio Thalles Almeida Silva
* Matricula: 201710568
* Inicio: 05/08/2018
* Ultima alteracao: 12/08/2018
* Nome: Problema do Trem
* Funcao: O programa utiliza de Threads para executar concorrentemente duas classes cada uma representando um carro e a funcao do programa eh fazer com que os carros nao se batam
*************************************************************** */
public class CarroVermelho extends Thread{
  
  Controlador c1;

  public void run(){
   /****************************************************************
  * Metodo: run
  * Funcao: tudo que estiver dentro do run sera executado pela thread
  * Parametros: nao tem parametros
  * Retorno: void
  ****************************************************************/
    try{
      while(true){ //loop infinito para o carro continuar andando
        Thread.sleep(50); //controle de tempo para controlar a ilusao de que o carro esta realmente se movendo como uma animacao
        c1.carroVermelho(); //chamada o metodo carroVermelho para que possamos comecar a execucao do carro vermelho
      }//fim while
    }//fim try
    catch(InterruptedException e){
          e.printStackTrace();
    }//fim do metodo catch
  }//fim do metodo run
 
  /****************************************************************
  * Metodo: setControlador
  * Funcao: receber a classe Controlador como parametro
  * Parametros:  Um objeto c da classe Controlador
  * Retorno: void
  ****************************************************************/
  public void setControlador(Controlador c){
    c1 = c;
  }//fim do metodo setControlador
}//fim da classe CarroVermelho