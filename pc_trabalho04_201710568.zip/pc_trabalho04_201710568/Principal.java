import java.io.IOException;
import javafx.application.Application;
import static javafx.application.Application.launch;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.stage.Stage;
import controladores.Controlador;

/* ***************************************************************
* Autor: Tharcio Thalles Almeida Silva
* Matricula: 201710568
* Inicio: 05/08/2018
* Ultima alteracao: 12/08/2018
* Nome: Problema do Trem uai so kkkk 
* Funcao: O programa utiliza de Threads para executar concorrentemente duas classes cada uma representando um carro e a funcao do programa eh fazer com que os carros nao se batam
*************************************************************** */

public class Principal extends Application {
  public static Stage palco;
  public static Scene pista;

  @Override
  public void start(Stage primaryStage) throws IOException {
    palco = primaryStage;

    Parent fxmlpista = FXMLLoader.load(getClass().getResource("/telas/pistateste.fxml"));// carrego o caminho relativo da tela
    
    pista = new Scene(fxmlpista); //mudo a cena para esse caminho

    primaryStage.setScene(pista);// passo a cena pro palco

    primaryStage.show(); // faco o palco ser exibido
  }//fim do metodo start
  public static void main(String[] args){
    launch(args);
  }//fim do main
}//fim da classe Principal