package controlador;

import carros.CarroP06;
import carros.CarroP09;
import carros.CarroP17;
import carros.CarroP14;
import carros.CarroP23;
import java.util.concurrent.Semaphore;
import java.net.URL;
import java.util.ResourceBundle;
import javafx.fxml.Initializable;
import javafx.scene.image.ImageView;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.fxml.FXML;
import javafx.application.Platform;
import javafx.scene.control.Slider;
import javafx.event.ActionEvent;

/*********************************************************************
* Classe: Controlador
* Funcao: controla todas as funcoes da tela
******************************************************************* */
public class Controlador implements Initializable {
  CarroP06 carroP06;
  CarroP09 carroP09;
  CarroP17 carroP17;
  CarroP14 carroP14;
  CarroP23 carroP23;

  @FXML public ImageView carroP06img;
  @FXML public ImageView carroP09img;
  @FXML public ImageView carroP17img;
  @FXML public ImageView carroP14img;
  @FXML public ImageView carroP23img;
  @FXML public ImageView pista;
  @FXML public ImageView pistaP06;
  @FXML public ImageView pistaP09;
  @FXML public ImageView pistaP23;
  @FXML public ImageView pistaP17;
  @FXML public ImageView pistaP14;

  @FXML Button start;
  @FXML public ImageView imgIniciar;
  @FXML Button p06;
  @FXML Button p09;
  @FXML Button p23;
  @FXML Button p17;
  @FXML Button p14;

  @FXML public Slider carroAmareloP06;
  @FXML public Slider carroVermelhoP09;
  @FXML public Slider carroAzulP23;
  @FXML public Slider carroRoxoP17;
  @FXML public Slider carroVerdeP14;

  Semaphore sem1x1e2x1; // c1 e c4
  Semaphore sem4x1e5x1; // c1 e c5
  Semaphore sem5x1;     //c1 e c5
  Semaphore sem3x2;     //c1 c4 e c5
  Semaphore sem3x2desc; // c4 e c5 
  Semaphore sem2x2e3x2; //c1 c2 e c3
  Semaphore sem4x2; //c1 c2 e c4
  Semaphore sem5x3e5x4; //c1 c2 c5 e c4
  Semaphore sem5x5e5x5e4x5; //c1 c4 e c5
  Semaphore sem3x5e2x5e1x5; //c1 e c3
  Semaphore sem1x5; //c1 e c3
  Semaphore sem1x5e2x5e3x5; //c1 c2 e c4
  Semaphore sem3x4; //c1 c3 e c5
  Semaphore sem4x3; //c1 e c4
  Semaphore sem3x3; //c1 c3 e c5
  Semaphore sem2x3; //c1 e c4
  Semaphore sem1x3; //c1 c2 c3 e c4
  Semaphore sem1x2e1x1; // c1 e c4
  Semaphore sem1x2; // c2 c3 e c4
  Semaphore sem1x4; // c2 e c3
  Semaphore sem4x5; // c3 c4 e c5
  Semaphore semcomp1; // c3 c4 e c5
  Semaphore semMorte; //c3 e c4
  Semaphore sem5x2; //c1 c2 e c4

  public Controlador(){
    start = new Button();
    p06 = new Button();
    p09 = new Button();
    p23 = new Button();
    p17 = new Button();
    p14 = new Button();
    imgIniciar = new ImageView();

    carroP06 = new CarroP06("carroP06");
    carroP09 = new CarroP09("carroP09");
    carroP17 = new CarroP17("carroP17");
    carroP14 = new CarroP14("carroP14");
    carroP23 = new CarroP23("carroP23");
    
    carroP06img = new ImageView();
    carroP09img = new ImageView(); 
    carroP17img = new ImageView();
    carroP14img = new ImageView();
    carroP23img = new ImageView();
    pista = new ImageView();
    pistaP06 = new ImageView();
    pistaP09 = new ImageView();
    pistaP23 = new ImageView();
    pistaP17 = new ImageView();
    pistaP14 = new ImageView();

    carroAmareloP06 = new Slider();
    carroVermelhoP09 = new Slider();
    carroAzulP23 = new Slider();
    carroRoxoP17 = new Slider();
    carroVerdeP14 = new Slider();

    semcomp1 = new Semaphore(1);
    sem1x1e2x1 = new Semaphore(1);
    sem4x1e5x1 = new Semaphore(0);
    sem5x1 = new Semaphore(1);
    sem3x2 = new Semaphore(1);
    sem3x2desc = new Semaphore(1);
    sem4x2 = new Semaphore(1);
    sem2x2e3x2 = new Semaphore(1);
    sem5x3e5x4 = new Semaphore(1);
    sem5x5e5x5e4x5 = new Semaphore(1);
    sem3x5e2x5e1x5 = new Semaphore(1);
    sem1x5 = new Semaphore(1);
    sem1x5e2x5e3x5 = new Semaphore(1);
    sem3x4 = new Semaphore(1);
    sem4x3 = new Semaphore(1);
    sem3x3 = new Semaphore(1);
    sem2x3 = new Semaphore(1);
    sem1x3 = new Semaphore(0);
    sem1x2e1x1 = new Semaphore(1);
    sem1x2 = new Semaphore(0);
    sem1x4 = new Semaphore(1);
    sem4x5 = new Semaphore(1);
    semMorte = new Semaphore(1);
    sem5x2 = new Semaphore(1);
  }//Fim construtor Controlador

  @Override
  public void initialize(URL url, ResourceBundle rb) {
    carroP06.setControlador(this); //passo o controlador por parametro para a classe carroP06
    carroP09.setControlador(this); //passo o controlador por parametro para a classe carroP09
    carroP17.setControlador(this); //passo o controlador por parametro para a classe carroP17
    carroP14.setControlador(this); //passo o controlador por parametro para a classe carroP14
    carroP23.setControlador(this); //passo o controlador por parametro para a classe carroP23
  } //fim do initialize

  public void iniciar(ActionEvent event){
    Platform.runLater(() -> {
      start.setVisible(false);
      imgIniciar.setVisible(false);
      carroP06.start(); // dou start na Thread do carroP06
      carroP09.start(); // dou start na Thread do carroP09
      carroP17.start(); // dou start na Thread do carroP17
      carroP14.start(); // dou start na Thread do carroP14
      carroP23.start(); // dou start na Thread do carroP23
    });//Fim Platform
  }//Fim iniciar

  public void percursoP06(ActionEvent event){
    Platform.runLater(() -> {
      pista.setVisible(false);
      pistaP09.setVisible(false);
      pistaP23.setVisible(false);
      pistaP17.setVisible(false);
      pistaP14.setVisible(false);
      pistaP06.setVisible(true);
    });//Fim Platform
  }//Fim metodo percursoP06

  public void percursoP09(ActionEvent event){
    Platform.runLater(() -> {
      pista.setVisible(false);
      pistaP06.setVisible(false);
      pistaP23.setVisible(false);
      pistaP17.setVisible(false);
      pistaP14.setVisible(false);
      pistaP09.setVisible(true);
    });//Fim Platform
  }//Fim metodo percursoP09

  public void percursoP23(ActionEvent event){
    Platform.runLater(() -> {
      pista.setVisible(false);
      pistaP06.setVisible(false);
      pistaP09.setVisible(false);
      pistaP17.setVisible(false);
      pistaP14.setVisible(false);
      pistaP23.setVisible(true);
    });//Fim Platform
  }//Fim metodo percursoP23

  public void percursoP14(ActionEvent event){
    Platform.runLater(() -> {
      pista.setVisible(false);
      pistaP06.setVisible(false);
      pistaP09.setVisible(false);
      pistaP17.setVisible(false);
      pistaP23.setVisible(false);
      pistaP14.setVisible(true);
    });//Fim Platform
  }//Fim metodo percursoP14

  public void percursoP17(ActionEvent event){
    Platform.runLater(() -> {
      pista.setVisible(false);
      pistaP06.setVisible(false);
      pistaP09.setVisible(false);
      pistaP23.setVisible(false);
      pistaP14.setVisible(false);
      pistaP17.setVisible(true);
    });//Fim Platform
  }//Fim metodo percursoP17

  public void down(String parametro){
    try{
      if(parametro == "sem1x1e2x1"){
        sem1x1e2x1.acquire();
      }//Fim if
      else if(parametro == "sem4x1e5x1"){
        sem4x1e5x1.acquire();
      }//Fim else if
      else if(parametro == "sem5x1"){
        sem5x1.acquire();
      }//Fim else if
      else if(parametro == "sem3x2"){
        sem3x2.acquire();
      }//Fim else if
      else if(parametro == "sem2x2e3x2"){
        sem2x2e3x2.acquire();
      }//Fim else if
      else if(parametro == "sem4x2"){
        sem4x2.acquire();
      }//Fim else if
      else if(parametro == "sem5x3e5x4"){
        sem5x3e5x4.acquire();
      }//Fim else if
      else if(parametro == "sem5x5e5x5e4x5"){
        sem5x5e5x5e4x5.acquire();
      }//Fim else if
      else if(parametro == "sem3x5e2x5e1x5"){
        sem3x5e2x5e1x5.acquire();
      }//Fim else if
      else if(parametro == "sem1x5"){
        sem1x5.acquire();
      }//Fim else if
      else if(parametro == "sem1x5e2x5e3x5"){
        sem1x5e2x5e3x5.acquire();
      }//Fim else if
      else if(parametro == "sem3x4"){
        sem3x4.acquire();
      }//Fim else if
      else if(parametro == "sem4x3"){
        sem4x3.acquire();
      }//Fim else if
      else if(parametro == "sem3x3"){
        sem3x3.acquire();
      }//Fim else if
      else if(parametro == "sem2x3"){
        sem2x3.acquire();
      }//Fim else if
      else if(parametro == "sem1x3"){
        sem1x3.acquire();
      }//Fim else if
      else if(parametro == "sem1x2e1x1"){
        sem1x2e1x1.acquire();
      }//Fim else if
      else if(parametro == "sem1x2"){
        sem1x2.acquire();
      }//Fim else if
      else if(parametro == "sem1x4"){
        sem1x4.acquire();
      }//Fim else if
      else if(parametro == "sem3x2desc"){
        sem3x2desc.acquire();
      }//Fim else if
      else if(parametro == "sem4x5"){
        sem4x5.acquire();
      }//Fim else if
      else if (parametro == "semcomp1"){
        semcomp1.acquire();
      }//Fim else if
      else if (parametro == "semMorte"){
        semMorte.acquire();
      }//Fim else if
      else if (parametro == "sem5x2"){
        sem5x2.acquire();
      }//Fim else if
    }catch(InterruptedException e){
      e.printStackTrace();
    }//Fim catch
  }//Fim down

  public void up(String parametro){
    if(parametro == "sem1x1e2x1"){
      sem1x1e2x1.release();
    }//Fim if
    else if(parametro == "sem4x1e5x1"){
      sem4x1e5x1.release();
    }//Fim if
    else if(parametro == "sem5x1"){
      sem5x1.release();
    }//Fim if
    else if(parametro == "sem3x2"){
      sem3x2.release();
    }//Fim else if
    else if(parametro == "sem2x2e3x2"){
      sem2x2e3x2.release();
    }//Fim else if
    else if(parametro == "sem4x2"){
      sem4x2.release();
    }//Fim else if
    else if(parametro == "sem5x3e5x4"){
      sem5x3e5x4.release();
    }//Fim else if
    else if(parametro == "sem5x5e5x5e4x5"){
      sem5x5e5x5e4x5.release();
    }//Fim else if
    else if(parametro == "sem3x5e2x5e1x5"){
      sem3x5e2x5e1x5.release();
    }//Fim else if
    else if(parametro == "sem1x5"){
      sem1x5.release();
    }//Fim else if
    else if(parametro == "sem1x5e2x5e3x5"){
      sem1x5e2x5e3x5.release();
    }//Fim else if
    else if(parametro == "sem3x4"){
      sem3x4.release();
    }//Fim else if
    else if(parametro == "sem4x3"){
      sem4x3.release();
    }//Fim else if
    else if(parametro == "sem3x3"){
      sem3x3.release();
    }//Fim else if
    else if(parametro == "sem2x3"){
      sem2x3.release();
    }//Fim else if
    else if(parametro == "sem1x3"){
      sem1x3.release();
    }//Fim else if
    else if(parametro == "sem1x2e1x1"){
      sem1x2e1x1.release();
    }//Fim else if
    else if(parametro == "sem1x2"){
      sem1x2.release();
    }//Fim else if
    else if(parametro == "sem1x4"){
      sem1x4.release();
    }//Fim else if
    else if(parametro == "sem3x2desc"){
      sem3x2desc.release();
    }//Fim else if sem3x2desc
    else if(parametro == "sem4x5"){
      sem4x5.release();
    }//Fim else if
    else if (parametro == "semcomp1"){
      semcomp1.release();
    }//Fim else if
    else if (parametro == "semMorte"){
      semMorte.release();
    }//Fim else if
    else if (parametro == "sem5x2"){
      sem5x2.release();
    }//Fim else if
  }//Fim up

  public void posicaoOriginal(ImageView carro){
    Platform.runLater(() -> {
      carro.setRotate(0);
    });//Fim Platform
  }//Fim metodo posicaoOriginal

  public void nomeCurvaDireita(String nome){
    if(nome == "carroP06"){
      curvaDireita(carroP06img);
    }//Fim if
    else if(nome == "carroP09"){
      curvaDireita(carroP09img);
    }//Fim else if
    else if(nome == "carroP17"){
      curvaDireita(carroP17img);
    }//Fim else if
    else if(nome == "carroP14"){
      curvaDireita(carroP14img);
    }//Fim else if
    else if(nome == "carroP23"){
      curvaDireita(carroP23img);
    }//Fim else if
  }//Fim metodo nomeCurvaDireita

  public void nomeCurvaEsquerdaMais(String nome,int sinal,int sinaly){
    if(nome == "carroP06"){
      curvaEsquerdaMais(carroP06img,sinal,sinaly);
    }//Fim if
    else if(nome == "carroP09"){
      curvaEsquerdaMais(carroP09img,sinal,sinaly);
    }//Fim else if
    else if(nome == "carroP17"){
      curvaEsquerdaMais(carroP17img,sinal,sinaly);
    }//Fim else if
    else if(nome == "carroP14"){
      curvaEsquerdaMais(carroP14img,sinal,sinaly);
    }//Fim else if
    else if(nome == "carroP23"){
      curvaEsquerdaMais(carroP23img,sinal,sinaly);
    }//Fim else if
  }//Fim metodo nomeCurvaDireita

  public void nomeCurvaEsquerdaMenos(String nome,int sinal,int sinalx){
    if(nome == "carroP06"){
      curvaEsquerdaMenos(carroP06img,sinal,sinalx);
    }//Fim if
    else if(nome == "carroP09"){
      curvaEsquerdaMenos(carroP09img,sinal,sinalx);
    }//Fim else if
    else if(nome == "carroP17"){
      curvaEsquerdaMenos(carroP17img,sinal,sinalx);
    }//Fim else if
    else if(nome == "carroP14"){
      curvaEsquerdaMenos(carroP14img,sinal,sinalx);
    }//Fim else if
    else if(nome == "carroP23"){
      curvaEsquerdaMenos(carroP23img,sinal,sinalx);
    }//Fim else if
  }//nomeCurvaEsquerdaDescendo

  public void CVD(ImageView carro, double rotacao){
    Platform.runLater(() -> {
      carro.setRotate(carro.getRotate() + rotacao);
      carro.setLayoutX(carro.getLayoutX() + 8);
    });//Fim Platform
  }//Fim CVD

  public void curvaDireita(ImageView carro){
    double rotacao = 0;
    while(rotacao <= 20){
      System.out.print(rotacao + " ");
      rotacao += 4;
      CVD(carro, rotacao);
      try{
        Thread.sleep(100);
      }catch(InterruptedException e){
        e.printStackTrace();
      }//Fim catch
    }//Fim while
    Platform.runLater(() -> {
      carro.setRotate(carro.getRotate() + 6);
    });//Fim Platform
    System.out.println("rotacao: " + carro.getRotate());
  }//Fim metodo curvaDireita

  public void CVEM(ImageView carro, int sinal,int sinaly,double rotacao){
    Platform.runLater(() -> {
      carro.setRotate(carro.getRotate() + (rotacao * sinal));
      carro.setLayoutY(carro.getLayoutY() + (7 * sinaly));
    });//Fim Platform
  }//Fim CVEM

  public void curvaEsquerdaMais(ImageView carro, int sinal,int sinaly){
    double rotacao = 0;
    while(rotacao <= 20){
      System.out.print(rotacao + " ");
      rotacao += 4;
      CVEM(carro, sinal, sinaly, rotacao);
      try{
        Thread.sleep(100);
      }catch(InterruptedException e){
        e.printStackTrace();
      }//Fim catch
    }//Fim while
    if(sinal > 0){
      Platform.runLater(() -> {
        carro.setRotate(carro.getRotate() + 7);
      });//Fim Platform
    }//Fim if
    else{
      Platform.runLater(() -> {
        carro.setRotate(carro.getRotate() - 5);
        //carro.setLayoutY(carro.getLayoutY() - 5);
      });//Fim Platform
    }//Fim else
    Platform.runLater(() -> {
      carro.setRotate(carro.getRotate() - 1);
    });//Fim Platform
    System.out.println("rotacao: " + carro.getRotate());
  }//Fim metodo curvaEsquerda

  public void CVEMEN(ImageView carro, int sinal,int sinalx,double rotacao){
    Platform.runLater(() -> {
      carro.setRotate(carro.getRotate() + (rotacao * sinal));
      carro.setLayoutX(carro.getLayoutX() + (8 * sinalx));
    });//Fim Platform
  }//Fim CVEMEN

  public void curvaEsquerdaMenos(ImageView carro,int sinal,int sinalx){
    double rotacao = 0;
    while(rotacao <= 20){
      System.out.print(rotacao + " ");
      rotacao += 4;
      CVEMEN(carro, sinal, sinalx, rotacao);
      try{
        Thread.sleep(100);
      }catch(InterruptedException e){
        e.printStackTrace();
      }//Fim catch
    }//Fim while
    if(carro.getRotate() > 100.0){
      Platform.runLater(() -> {
        carro.setRotate(270.0);
      });//Fim Platform
    }//Fim if
    else{
      Platform.runLater(() -> {
        carro.setRotate(90.0);
      });//Fim Platform
    }//Fim else
    System.out.println("rotacao: " + carro.getRotate());
  }//Fim metodo curvaEsquerda



  public void moverXMais(ImageView carro,int velocidade){
    Platform.runLater(() -> {
      carro.setLayoutX(carro.getLayoutX() + velocidade);
    });//Fim Platform
  }//Fim metodo moverXMais

  public void moverXMenos(ImageView carro,int velocidade){
    Platform.runLater(() -> {
      carro.setLayoutX(carro.getLayoutX() - velocidade);
    });//Fim Platform
  }//Fim metodo moverXMenos

  public void moverYMais(ImageView carro,int velocidade){
    Platform.runLater(() -> {
      carro.setLayoutY(carro.getLayoutY() + velocidade);
    });//Fim Platform
  }//Fim metodo moverYMais

  public void moverYMenos(ImageView carro,int velocidade){
    Platform.runLater(() -> {
      carro.setLayoutY(carro.getLayoutY() - velocidade);
    });//Fim Platform
  }//Fim metodo moverYMenos

  /*******************CARRO P06 CONTROLES********************************/
  public void carroP06T1(){
    //Regiao critica
    while(carroP06img.getLayoutX() < 260.0 ){
      moverXMais(carroP06img,(int)carroAmareloP06.getValue());
      try{
        Thread.sleep(50);
      }catch(InterruptedException e){
        e.printStackTrace();
      }//Fim catch
    }//Fim while
  }//Fim metodo carroP06T1

  public void carroP06T2(){
    //Regiao nao critica
    while(carroP06img.getLayoutX() < 295.0 ){
      moverXMais(carroP06img,(int)carroAmareloP06.getValue());
      try{
        Thread.sleep(50);
      }catch(InterruptedException e){
        e.printStackTrace();
      }//Fim catch
    }//Fim while
  }//Fim metodo carroP06T2

  public void carroP06T3(){
    //Regiao critica
    while(carroP06img.getLayoutX() < 516.0 ){
      moverXMais(carroP06img,(int)carroAmareloP06.getValue());
      try{
        Thread.sleep(50);
      }catch(InterruptedException e){
        e.printStackTrace();
      }//Fim catch
    }//Fim while
  }//Fim metodo carroP06T3

   public void carroP06T4(){
    //Regiao critica
    while(carroP06img.getLayoutY() < 52.0){
      moverYMais(carroP06img,(int)carroAmareloP06.getValue());
      try{
        Thread.sleep(50);
      }catch(InterruptedException e){
        e.printStackTrace();
      }//Fim catch
    }//Fim while
    /*try{
      Thread.sleep(500000);
    }catch(InterruptedException e){
      e.printStackTrace();
    }//Fim catch*/
  }//Fim metodo carroP06T4

  public void carroP06T5(){
    //Regiao nao critica
    while(carroP06img.getLayoutX() > 410.0){
      moverXMenos(carroP06img,(int)carroAmareloP06.getValue());
      try{
        Thread.sleep(50);
      }catch(InterruptedException e){
        e.printStackTrace();
      }//Fim catch
    }//Fim while
  }//Fim metodo carroP06T5

  public void carroP06T6(){
    //Regiao critica
    while(carroP06img.getLayoutX() > 160.0){
      moverXMenos(carroP06img,(int)carroAmareloP06.getValue());
      try{
        Thread.sleep(50);
      }catch(InterruptedException e){
        e.printStackTrace();
      }//Fim catch
    }//Fim while
  }//Fim metodo carroP06T6

   public void carroP06T7(){
    //Regiao nao critica
    while(carroP06img.getLayoutX() > 160.0){
      moverXMenos(carroP06img,(int)carroAmareloP06.getValue());
      try{
        Thread.sleep(50);
      }catch(InterruptedException e){
        e.printStackTrace();
      }//Fim catch
    }//Fim while
  }//Fim metodo carroP06T7

  public void carroP06T8(){
    //Regiao nao critica
    while(carroP06img.getLayoutY() < 128.0){
      moverYMais(carroP06img,(int)carroAmareloP06.getValue());
      try{
        Thread.sleep(50);
      }catch(InterruptedException e){
        e.printStackTrace();
      }//Fim catch
    }//Fim while
  }//Fim metodo carroP06T8

  public void carroP06T9(){
    //Regiao critica
    while(carroP06img.getLayoutX() < 292.0){
      moverXMais(carroP06img,(int)carroAmareloP06.getValue());
      try{
        Thread.sleep(50);
      }catch(InterruptedException e){
        e.printStackTrace();
      }//Fim catch
    }//Fim while
  }//Fim metodo carroP06T9

  public void carroP06T10(){
    //Regiao critica
    while(carroP06img.getLayoutX() < 412.0){
      moverXMais(carroP06img,(int)carroAmareloP06.getValue());
      try{
        Thread.sleep(50);
      }catch(InterruptedException e){
        e.printStackTrace();
      }//Fim catch
    }//Fim while
  }//Fim metodo carroP06T10

  public void carroP06T10V2(){
    //Regiao critica
    while(carroP06img.getLayoutX() < 515.0){
      moverXMais(carroP06img,(int)carroAmareloP06.getValue());
      try{
        Thread.sleep(50);
      }catch(InterruptedException e){
        e.printStackTrace();
      }//Fim catch
    }//Fim while
  }//Fim metodo carroP06T10V2

  public void carroP06T11(){
    //Regiao critica
    while(carroP06img.getLayoutY() < 295.0){
      moverYMais(carroP06img,(int)carroAmareloP06.getValue());
      try{
        Thread.sleep(50);
      }catch(InterruptedException e){
        e.printStackTrace();
      }//Fim catch
    }//Fim while
  }//Fim metodo carroP06T11

  public void carroP06T12(){
    //Regiao critica
    while(carroP06img.getLayoutY() < 383.0){
      moverYMais(carroP06img,(int)carroAmareloP06.getValue());
      try{
        Thread.sleep(50);
      }catch(InterruptedException e){
        e.printStackTrace();
      }//Fim catch
    }//Fim while

    nomeCurvaEsquerdaMais("carroP06",1,1);

    while(carroP06img.getLayoutX() > 400){
      moverXMenos(carroP06img,(int)carroAmareloP06.getValue());
      try{
        Thread.sleep(50);
      }catch(InterruptedException e){
        e.printStackTrace();
      }//Fim catch
    }//Fim while
  }//Fim metodo carroP06T12

  public void carroP06T13(){
    //Regiao critica
    while(carroP06img.getLayoutX() > 50.0){
      moverXMenos(carroP06img,(int)carroAmareloP06.getValue());
      try{
        Thread.sleep(50);
      }catch(InterruptedException e){
        e.printStackTrace();
      }//Fim catch
    }//Fim while
  }//Fim metodo carroP06T13

  public void carroP06T14(){
    //Regiao critica
    nomeCurvaEsquerdaMenos("carroP06",1,-1);
    while(carroP06img.getLayoutY() > 388.0){
      moverYMenos(carroP06img,(int)carroAmareloP06.getValue());
      try{
        Thread.sleep(50);
      }catch(InterruptedException e){
        e.printStackTrace();
      }//Fim catch
    }//Fim while
  }//Fim metodo carroP06T14

  public void carroP06T15(){
    //Regiao critica
    nomeCurvaEsquerdaMais("carroP06",1,-1);
    while(carroP06img.getLayoutX() < 290.0){
      moverXMais(carroP06img,(int)carroAmareloP06.getValue());
      try{
        Thread.sleep(50);
      }catch(InterruptedException e){
        e.printStackTrace();
      }//Fim catch
    }//Fim while
  }//Fim metodo carroP06T15

  public void carroP06T16(){
    //Regiao critica
    while(carroP06img.getLayoutX() < 408.0){
      moverXMais(carroP06img,(int)carroAmareloP06.getValue());
      try{
        Thread.sleep(50);
      }catch(InterruptedException e){
        e.printStackTrace();
      }//Fim catch
    }//Fim while
  }//Fim metodo carroP06T16

  public void carroP06T17(){
    //Regiao critica
    nomeCurvaEsquerdaMenos("carroP06",-1,1);
    while(carroP06img.getLayoutY() > 300.0){
      moverYMenos(carroP06img,(int)carroAmareloP06.getValue());
      try{
        Thread.sleep(50);
      }catch(InterruptedException e){
        e.printStackTrace();
      }//Fim catch
    }//Fim while  
  }//Fim metodo carroP06T17

  public void carroP06T18(){
    //Regiao critica
    nomeCurvaEsquerdaMais("carroP06",-1,-1);
    while(carroP06img.getLayoutX() > 400.0){
      moverXMenos(carroP06img,(int)carroAmareloP06.getValue());
      try{
        Thread.sleep(50);
      }catch(InterruptedException e){
        e.printStackTrace();
      }//Fim catch
    }//Fim while
  }//Fim metodo carroP06T18  

  public void carroP06T19(){
    //Regiao critica
    while(carroP06img.getLayoutX() > 290.0){
      moverXMenos(carroP06img,(int)carroAmareloP06.getValue());
      try{
        Thread.sleep(50);
      }catch(InterruptedException e){
        e.printStackTrace();
      }//Fim catch
    }//Fim while
  }//Fim metodo carroP06T19 

   public void carroP06T20(){
    //Regiao critica
    while(carroP06img.getLayoutX() > 170.0){
      moverXMenos(carroP06img,(int)carroAmareloP06.getValue());
      try{
        Thread.sleep(50);
      }catch(InterruptedException e){
        e.printStackTrace();
      }//Fim catch
    }//Fim while
  }//Fim metodo carroP06T20

  public void carroP06T21(){
    //Regiao critica
    while(carroP06img.getLayoutX() > 50.0){
      moverXMenos(carroP06img,(int)carroAmareloP06.getValue());
      try{
        Thread.sleep(50);
      }catch(InterruptedException e){
        e.printStackTrace();
      }//Fim catch
    }//Fim while
  }//Fim metodo carroP06T21

  public void carroP06T22(){
    //Regiao critica
    nomeCurvaEsquerdaMenos("carroP06",1,-1);
    while(carroP06img.getLayoutY() > 220.0){
      moverYMenos(carroP06img,(int)carroAmareloP06.getValue());
      try{
        Thread.sleep(50);
      }catch(InterruptedException e){
        e.printStackTrace();
      }//Fim catch
    }//Fim while  
  }//Fim metodo carroP06T17

  public void carroP06T23(){
    //Regiao critica
    while(carroP06img.getLayoutY() > 45.0){
      moverYMenos(carroP06img,(int)carroAmareloP06.getValue());
      try{
        Thread.sleep(50);
      }catch(InterruptedException e){
        e.printStackTrace();
      }//Fim catch
    }//Fim while  
  }//Fim metodo carroP06T23

  /*******************FIM CARRO P06 CONTROLES********************************/

  /*************************************************************************/
  
  /*******************CARRO P09 CONTROLES********************************/
  public void carroP09T1(){
    //Regiao critica
    while(carroP09img.getLayoutX() < 55.0){
      moverXMais(carroP09img,(int)carroVermelhoP09.getValue());
    try{
        Thread.sleep(50);
      }catch(InterruptedException e){
        e.printStackTrace();
      }//Fim catch
    }//Fim while  
  }//Fim metodo carroP09T1

  public void carroP09T2(){
    //Regiao critica
    while(carroP09img.getLayoutX() < 280.0){
      moverXMais(carroP09img,(int)carroVermelhoP09.getValue());
    try{
        Thread.sleep(50);
      }catch(InterruptedException e){
        e.printStackTrace();
      }//Fim catch
    }//Fim while  
  }//Fim metodo carroP09T2

  public void carroP09T3(){
    //Regiao critica
    while(carroP09img.getLayoutX() < 412.0){
      moverXMais(carroP09img,(int)carroVermelhoP09.getValue());
      try{
        Thread.sleep(50);
      }catch(InterruptedException e){
        e.printStackTrace();
      }//Fim catch
    }//Fim while
  }//Fim metodo carroP09T3

  public void carroP09T3V2(){
    //Regiao critica
    while(carroP09img.getLayoutX() < 515.0){
      moverXMais(carroP09img,(int)carroVermelhoP09.getValue());
      try{
        Thread.sleep(50);
      }catch(InterruptedException e){
        e.printStackTrace();
      }//Fim catch
    }//Fim while
  }//Fim metodo carroP09T3V2

  public void carroP09T4(){  
    //Regiao critica
    while(carroP09img.getLayoutY() < 295.0){
      moverYMais(carroP09img,(int)carroVermelhoP09.getValue());
      try{
        Thread.sleep(50);
      }catch(InterruptedException e){
        e.printStackTrace();
      }//Fim catch
    }//Fim while
  }//Fim metodo carroP09T4

  public void carroP09T5(){
    //Regiao critica
    while(carroP09img.getLayoutX() > 518.0){
      moverXMenos(carroP09img,(int)carroVermelhoP09.getValue());
      try{
        Thread.sleep(50);
      }catch(InterruptedException e){
        e.printStackTrace();
      }//Fim catch
    }//Fim while
  }//Fim metodo carroP09T5

  public void carroP09T6(){
    //Regiao critica
    while(carroP09img.getLayoutX() > 406.0){
      moverXMenos(carroP09img,(int)carroVermelhoP09.getValue());
      try{
        Thread.sleep(50);
      }catch(InterruptedException e){
        e.printStackTrace();
      }//Fim catch
    }//Fim while
  }//Fim metodo carroP09T6

  public void carroP09T7(){
    //Regiao critica
    while(carroP09img.getLayoutX() > 53.0){
      moverXMenos(carroP09img,(int)carroVermelhoP09.getValue());
      try{
        Thread.sleep(50);
      }catch(InterruptedException e){
        e.printStackTrace();
      }//Fim catch
    }//Fim while
  }//Fim metodo carroP09T7

  public void carroP09T8(){
    //Regiao critica
    while(carroP09img.getLayoutY() > 302.0){
      moverYMenos(carroP09img,(int)carroVermelhoP09.getValue());
      try{
        Thread.sleep(50);
      }catch(InterruptedException e){
        e.printStackTrace();
      }//Fim catch
    }//Fim while
  }//Fim metodo carroP09T8

  public void carroP09T9(){
    //Regiao critica
    while(carroP09img.getLayoutY() > 217.0){
      moverYMenos(carroP09img,(int)carroVermelhoP09.getValue());
      try{
        Thread.sleep(50);
      }catch(InterruptedException e){
        e.printStackTrace();
      }//Fim catch
    }//Fim while
  }//Fim metodo carroP09T9

  /*******************FIM CARRO P09 CONTROLES********************************/

  /*************************************************************************/

  /*******************CARRO P17 CONTROLES********************************/

  public void carroP17T0(){
    //Regiao critica
    nomeCurvaEsquerdaMais("carroP17",1,1);
  }//Fim metodo carroP17T0

  public void carroP17T1(){
    //Regiao critica
    while(carroP17img.getLayoutX() > 53.0){
      moverXMenos(carroP17img,(int)carroRoxoP17.getValue());
      try{
        Thread.sleep(50);
      }catch(InterruptedException e){
        e.printStackTrace();
      }//Fim catch
    }//Fim while
  }//Fim metodo carroP17T1

   public void carroP17T2(){
    //Regiao critica
    nomeCurvaEsquerdaMenos("carroP17",1,-1);
    while(carroP17img.getLayoutY() > 380.0){
      moverYMenos(carroP17img,(int)carroRoxoP17.getValue());
      try{
        Thread.sleep(50);
      }catch(InterruptedException e){
        e.printStackTrace();
      }//Fim catch
    }//Fim while
  }//Fim metodo carroP17T2

  public void carroP17T3(){
    //Regiao critica
    while(carroP17img.getLayoutY() > 302.0){
      moverYMenos(carroP17img,(int)carroRoxoP17.getValue());
      try{
        Thread.sleep(50);
      }catch(InterruptedException e){
        e.printStackTrace();
      }//Fim catch
    }//Fim while
  }//Fim metodo carroP17T3

  public void carroP17T4(){
    //Regiao critica
    while(carroP17img.getLayoutY() > 217.0){
      moverYMenos(carroP17img,(int)carroRoxoP17.getValue());
      try{
        Thread.sleep(50);
      }catch(InterruptedException e){
        e.printStackTrace();
      }//Fim catch
    }//Fim while
  }//Fim metodo carroP17T4

  public void carroP17T5(){
    //Regiao critica
    while(carroP17img.getLayoutX() < 55.0){
      moverXMais(carroP17img,(int)carroRoxoP17.getValue());
      try{
        Thread.sleep(50);
      }catch(InterruptedException e){
        e.printStackTrace();
      }//Fim catch
    }//Fim while  
  }//Fim metodo carroP17T5

  public void carroP17T6(){
    //Regiao critica
    while(carroP17img.getLayoutX() < 295.0){
      moverXMais(carroP17img,(int)carroRoxoP17.getValue());
      try{
        Thread.sleep(50);
      }catch(InterruptedException e){
        e.printStackTrace();
      }//Fim catch
    }//Fim while  
  }//Fim metodo carroP17T6

  public void carroP17T7(){
    //Regiao critica
    nomeCurvaDireita("carroP17");
    while(carroP17img.getLayoutY() < 298.0){
      moverYMais(carroP17img,(int)carroRoxoP17.getValue());
      try{
        Thread.sleep(50);
      }catch(InterruptedException e){
        e.printStackTrace();
      }//Fim catch
    }//Fim while  
  }//Fim metodo carroP17T7

  public void carroP17T8(){
    //Regiao critica
    while(carroP17img.getLayoutY() < 382.0){
      moverYMais(carroP17img,(int)carroRoxoP17.getValue());
      try{
        Thread.sleep(50);
      }catch(InterruptedException e){
        e.printStackTrace();
      }//Fim catch
    }//Fim while  
  }//Fim metodo carroP17T8

  /*******************FIM CARRO P17 CONTROLES********************************/

  /*************************************************************************/

  /*******************CARRO P14 CONTROLES********************************/

  public void carroP14T1(){
    //Regiao critica
    while(carroP14img.getLayoutX() < 516.0 ){
      moverXMais(carroP14img,(int)carroVerdeP14.getValue());
      try{
        Thread.sleep(50);
      }catch(InterruptedException e){
        e.printStackTrace();
      }//Fim catch
    }//Fim while
  }//Fim metodo carroP14T1


  public void carroP14T2(){
    //Regiao critica
    while(carroP14img.getLayoutY() < 52.0){
      moverYMais(carroP14img,(int)carroVerdeP14.getValue());
      try{
        Thread.sleep(50);
      }catch(InterruptedException e){
        e.printStackTrace();
      }//Fim catch
    }//Fim while
  }//Fim metodo carroP14T2

  public void carroP14T3(){
    //Regiao nao critica
    while(carroP14img.getLayoutY() < 130.0){
      moverYMais(carroP14img,(int)carroVerdeP14.getValue());
      try{
        Thread.sleep(50);
      }catch(InterruptedException e){
        e.printStackTrace();
      }//Fim catch
    }//Fim while
  }//Fim metodo carroP14T3

  public void carroP14T4(){
    //Regiao critica
    while(carroP14img.getLayoutY() < 295.0){
      moverYMais(carroP14img,(int)carroVerdeP14.getValue());
      try{
        Thread.sleep(50);
      }catch(InterruptedException e){
        e.printStackTrace();
      }//Fim catch
    }//Fim while
  }//Fim metodo carroP14T4

  public void carroP14T5(){
    //Regiao critica
    while(carroP14img.getLayoutY() < 383.0){
      moverYMais(carroP14img,(int)carroVerdeP14.getValue());
      try{
        Thread.sleep(50);
      }catch(InterruptedException e){
        e.printStackTrace();
      }//Fim catch
    }//Fim while

    nomeCurvaEsquerdaMais("carroP14",1,1);

    while(carroP14img.getLayoutX() > 400){
      moverXMenos(carroP14img,(int)carroVerdeP14.getValue());
      try{
        Thread.sleep(50);
      }catch(InterruptedException e){
        e.printStackTrace();
      }//Fim catch
    }//Fim while
  }//Fim metodo carroP14T5  

  public void carroP14T6(){
    //Regiao critica
    nomeCurvaEsquerdaMenos("carroP14",1,-1);
    while(carroP14img.getLayoutY() > 392.0){
      moverYMenos(carroP14img,(int)carroVerdeP14.getValue());
      try{
        Thread.sleep(50);
      }catch(InterruptedException e){
        e.printStackTrace();
      }//Fim catch
    }//Fim while
  }//Fim metodo carroP14T6

  public void carroP14T7(){
    //Regiao critica
    while(carroP14img.getLayoutY() > 222.0){
      moverYMenos(carroP14img,(int)carroVerdeP14.getValue());
      try{
        Thread.sleep(50);
      }catch(InterruptedException e){
        e.printStackTrace();
      }//Fim catch
    }//Fim while
  }//Fim metodo carroP14T7

  public void carroP14T8(){
    //Regiao critica
    while(carroP14img.getLayoutY() > 52.0){
      moverYMenos(carroP14img,(int)carroVerdeP14.getValue());
      try{
        Thread.sleep(50);
      }catch(InterruptedException e){
        e.printStackTrace();
      }//Fim catch
    }//Fim while
  }//Fim metodo carroP14T8

  public void carroP14T9(){
    //Regiao critica
    while(carroP14img.getLayoutY() > 45.0){
      moverYMenos(carroP14img,(int)carroVerdeP14.getValue());
      try{
        Thread.sleep(50);
      }catch(InterruptedException e){
        e.printStackTrace();
      }//Fim catch
    }//Fim while
    nomeCurvaEsquerdaMais("carroP14",1,-1);
  }//Fim metodo carroP14T9

  /*******************FIM CARRO P14 CONTROLES********************************/

  /*************************************************************************/

  /*******************CARRO P23 CONTROLES********************************/

  public void carroP23T1(){
    //Regiao critica
    while(carroP23img.getLayoutX() < 280.0){
      moverXMais(carroP23img,(int)carroAzulP23.getValue());
      try{
        Thread.sleep(50);
      }catch(InterruptedException e){
        e.printStackTrace();
      }//Fim catch
    }//Fim while
  }//Fim metodo carroP23T1

  public void carroP23T2(){
    //Regiao critica
    while(carroP23img.getLayoutY() < 125.0){
      moverYMais(carroP23img,(int)carroAzulP23.getValue());
      try{
        Thread.sleep(50);
      }catch(InterruptedException e){
        e.printStackTrace();
      }//Fim catch
    }//Fim while
  }//Fim metodo carroP23T2

  public void carroP23T3(){
    //Regiao critica
    while(carroP23img.getLayoutX() < 403.0){
      moverXMais(carroP23img,(int)carroAzulP23.getValue());
      try{
        Thread.sleep(50);
      }catch(InterruptedException e){
        e.printStackTrace();
      }//Fim catch
    }//Fim while
  }//Fim metodo carroP23T3

  public void carroP23T4(){
    //Regiao nao critica
    while(carroP23img.getLayoutY() < 213.0){
      moverYMais(carroP23img,(int)carroAzulP23.getValue());
      try{
        Thread.sleep(50);
      }catch(InterruptedException e){
        e.printStackTrace();
      }//Fim catch
    }//Fim while
  }//Fim metodo carroP23T4

  public void carroP23T5(){
    //Regiao nao critica
    while(carroP23img.getLayoutX() < 505.0){
      moverXMais(carroP23img,(int)carroAzulP23.getValue());
      try{
        Thread.sleep(50);
      }catch(InterruptedException e){
        e.printStackTrace();
      }//Fim catch
    }//Fim while
  }//Fim metodo carroP23T5

  public void carroP23T6(){
    //Regiao nao critica
    while(carroP23img.getLayoutY() < 298.0){
      moverYMais(carroP23img,(int)carroAzulP23.getValue());
      try{
        Thread.sleep(50);
      }catch(InterruptedException e){
        e.printStackTrace();
      }//Fim catch
    }//Fim while
  }//Fim metodo carroP23T6

  public void carroP23T7(){
    //Regiao critica
    while(carroP23img.getLayoutY() < 383.0){
      moverYMais(carroP23img,(int)carroAzulP23.getValue());
      try{
        Thread.sleep(50);
      }catch(InterruptedException e){
        e.printStackTrace();
      }//Fim catch
    }//Fim while

    nomeCurvaEsquerdaMais("carroP23",1,1);

    while(carroP23img.getLayoutX() > 400){
      moverXMenos(carroP23img,(int)carroAzulP23.getValue());
      try{
        Thread.sleep(50);
      }catch(InterruptedException e){
        e.printStackTrace();
      }//Fim catch
    }//Fim while
  }//Fim metodo carroP23T7

  public void carroP23T8(){
    //Regiao critica
    while(carroP23img.getLayoutY() > 392.0){
      moverYMenos(carroP23img,(int)carroAzulP23.getValue());
      try{
        Thread.sleep(50);
      }catch(InterruptedException e){
        e.printStackTrace();
      }//Fim catch
    }//Fim while
  }//Fim metodo carroP23T8

  public void carroP23T9(){
    //Regiao critica
    while(carroP23img.getLayoutX() > 284.0){
      moverXMenos(carroP23img,(int)carroAzulP23.getValue());
      try{
        Thread.sleep(50);
      }catch(InterruptedException e){
        e.printStackTrace();
      }//Fim catch
    }//Fim while
  }//Fim metodo carroP23T9

  public void carroP23T10(){
    //Regiao nao critica
    while(carroP23img.getLayoutY() > 301.0){
      moverYMenos(carroP23img,(int)carroAzulP23.getValue());
      try{
        Thread.sleep(50);
      }catch(InterruptedException e){
        e.printStackTrace();
      }//Fim catch
    }//Fim while
  }//Fim metodo carroP23T10

  public void carroP23T11(){
    //Regiao critica
    while(carroP23img.getLayoutX() > 163.0){
      moverXMenos(carroP23img,(int)carroAzulP23.getValue());
      try{
        Thread.sleep(50);
      }catch(InterruptedException e){
        e.printStackTrace();
      }//Fim catch
    }//Fim while
  }//Fim metodo carroP23T11

  public void carroP23T12(){
    //Regiao nao critica
    while(carroP23img.getLayoutY() > 214.0){
      moverYMenos(carroP23img,(int)carroAzulP23.getValue());
      try{
        Thread.sleep(50);
      }catch(InterruptedException e){
        e.printStackTrace();
      }//Fim catch
    }//Fim while
  }//Fim metodo carroP23T12

  public void carroP23T13(){
    //Regiao critica
    while(carroP23img.getLayoutX() > 48.0){
      moverXMenos(carroP23img,(int)carroAzulP23.getValue());
      try{
        Thread.sleep(50);
      }catch(InterruptedException e){
        e.printStackTrace();
      }//Fim catch
    }//Fim while
  }//Fim metodo carroP23T13

  public void carroP23T14(){
    //Regiao critica
    while(carroP23img.getLayoutY() > 54.0){
      moverYMenos(carroP23img,(int)carroAzulP23.getValue());
      try{
        Thread.sleep(50);
      }catch(InterruptedException e){
        e.printStackTrace();
      }//Fim catch
    }//Fim while
  }//Fim metodo carroP23T14

  public void carroP23T15(){
    //Regiao critica
    while(carroP23img.getLayoutX() < 165.0){
      moverXMais(carroP23img,(int)carroAzulP23.getValue());
      try{
        Thread.sleep(50);
      }catch(InterruptedException e){
        e.printStackTrace();
      }//Fim catch
    }//Fim while
  }//Fim metodo carroP23T15

  public void carroP23T16(){
    //Regiao critica
    while(carroP23img.getLayoutY() < 44.0){
      moverYMais(carroP23img,(int)carroAzulP23.getValue());
      try{
        Thread.sleep(50);
      }catch(InterruptedException e){
        e.printStackTrace();
      }//Fim catch
    }//Fim while
  }//Fim metodo carroP23T16
  
/*******************FIM CARRO P23 CONTROLES********************************/

}//Fim classe Controlador