package carros;

import controlador.Controlador;

public class CarroP14 extends Thread{
  Controlador control;
  String nome;
  
  public CarroP14(String nome){
    this.nome = nome;
  }//Fim construtor carroP06

  //verde
  public void run(){
    while(true){
      control.posicaoOriginal(control.carroP14img);

      control.carroP14T1(); //regiao critica

      control.down("sem5x1");
        control.nomeCurvaDireita(this.nome);
        control.up("sem4x1e5x1");
        control.carroP14T2(); //regiao critica
      control.up("sem5x1");

      control.carroP14T3(); //regiao nao critica

      control.down("sem5x3e5x4");
        control.carroP14T4();

      control.down("sem5x5e5x5e4x5");
        control.up("sem5x3e5x4");
        control.carroP14T5(); //regiao critica
      
      
      control.down("sem3x3");
      control.down("sem3x4");
      control.down("sem4x5");
        control.up("sem5x5e5x5e4x5");
        control.carroP14T6(); //regiao critica
        control.up("sem4x5");
        control.carroP14T7(); //regiao critica
        control.up("sem3x4");

      control.down("sem3x2");
      control.down("sem3x2desc");
        control.carroP14T8(); //regiao critica
        control.up("sem3x3");
      control.up("sem3x2desc");
      control.up("sem3x2");

      control.down("sem4x1e5x1");
        control.carroP14T9(); //regiao critica
        
    }//Fim while
  }//Fim metodo run

   public void setControlador(Controlador c){
    control = c;
  } //fim do metodo setControlador

}//Fim classe CarroP14