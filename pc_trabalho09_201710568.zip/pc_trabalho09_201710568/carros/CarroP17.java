package carros;

import controlador.Controlador;

public class CarroP17 extends Thread{
  Controlador control;
  String nome;
  int cont = 0;
  public CarroP17(String nome){
    this.nome = nome;
  }//Fim construtor carroP17

  public void run(){
    //roxo
    while(true){
      control.posicaoOriginal(control.carroP17img);

      control.down("sem2x2e3x2");
        control.carroP17T6(); //regiao critica
        control.up("sem1x2");
      
      control.down("sem3x3"); 
      control.down("sem4x2");
        control.up("sem2x2e3x2");
        control.carroP17T7(); //regiao critica
      control.up("sem4x2");

      control.down("sem3x4");
      control.down("sem4x5");
        control.up("sem3x3");
        control.carroP17T8(); //regiao critica
      control.up("sem3x4");

      control.down("sem3x5e2x5e1x5");
        control.carroP17T0();
        control.up("sem4x5");
        control.carroP17T1(); //regiao critica

      control.down("sem1x5");
        control.carroP17T2(); //regiao critica
        control.up("sem3x5e2x5e1x5");

      control.down("sem1x4");
        control.up("sem1x5");
        control.carroP17T3(); //regiao critica

      control.down("sem1x3");
        control.up("sem1x4");
        control.carroP17T4();

      control.down("sem1x2");
        control.nomeCurvaEsquerdaMais("carroP17",1,-1);
        control.up("sem1x3");
        control.carroP17T5(); //regiao critica
    }//Fim while
  }//Fim metodo run

  public void setControlador(Controlador c){
    control = c;
  } //fim do metodo setControlador

}//Fim classe CarroP17