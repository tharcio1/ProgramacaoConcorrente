package carros;

import controlador.Controlador;

public class CarroP23 extends Thread{
  Controlador control;
  String nome;
  int cont = 0;
  
  public CarroP23(String nome){
    this.nome = nome;
  }//Fim construtor carroP23

  //azul
  public void run(){
    while(true){
      control.down("sem3x2");
        if(cont == 1){
          control.nomeCurvaEsquerdaMais(this.nome,-1,1);
          control.posicaoOriginal(control.carroP23img);
        }//Fim if
        control.carroP23T1(); //regiao critica


      control.down("sem3x2desc");
        control.nomeCurvaDireita(this.nome);
        control.carroP23T2(); //regiao critica
        control.up("sem3x2");

      control.down("sem4x2");
        control.nomeCurvaEsquerdaMais(this.nome,-1,1);
        control.carroP23T3(); //regiao critica
        control.up("sem3x2desc");

      control.nomeCurvaDireita(this.nome); //regiao nao critica
      control.up("sem4x2");
      control.carroP23T4(); //regiao nao critica

      control.down("sem4x3");
        control.nomeCurvaEsquerdaMais(this.nome,-1,1);
        control.carroP23T5(); //regiao critica
      control.up("sem4x3");

      control.down("sem5x3e5x4");
        control.nomeCurvaDireita(this.nome);
        control.carroP23T6(); //regiao critica

      control.down("sem5x5e5x5e4x5");
        control.up("sem5x3e5x4");
        control.carroP23T7(); //regiao critica

      control.down("sem4x5");
        control.up("sem5x5e5x5e4x5");
        control.nomeCurvaEsquerdaMenos("carroP23",1,-1);
        control.carroP23T8(); //regiao critica

      control.down("sem1x5e2x5e3x5");
        control.nomeCurvaEsquerdaMais("carroP23",-1,-1);
        control.carroP23T9(); //regiao critica
        control.up("sem4x5");

      control.nomeCurvaEsquerdaMenos("carroP23",1,-1);
      control.up("sem1x5e2x5e3x5");
      control.carroP23T10(); //regiao nao critica

      control.down("sem2x3");
        control.nomeCurvaEsquerdaMais("carroP23",-1,-1);
        control.carroP23T11(); //regiao critica

      control.nomeCurvaEsquerdaMenos("carroP23",1,-1);
        control.up("sem2x3");
      control.carroP23T12(); //regiao nao critica

      control.down("sem1x2");
        control.nomeCurvaEsquerdaMais("carroP23",-1,-1);
        control.carroP23T13(); //regiao critica

      control.down("sem1x2e1x1");
        control.nomeCurvaEsquerdaMenos("carroP23",1,-1);
        control.up("sem1x2");
        control.carroP23T14(); //regiao critica

      control.down("sem1x1e2x1");
        control.nomeCurvaEsquerdaMais("carroP23",1,-1);
        control.up("sem1x2e1x1");
        control.carroP23T15(); //regiao critica

      control.nomeCurvaDireita(this.nome);
        control.up("sem1x1e2x1");
      control.carroP23T16(); //regiao nao critica

      cont = 1; //controle da curva

    }//Fim while
  }//Fim metodo run

  public void setControlador(Controlador c){
    control = c;
  } //fim do metodo setControlador

}//Fim classe CarroP23