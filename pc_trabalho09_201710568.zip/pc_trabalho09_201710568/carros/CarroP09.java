package carros;

import controlador.Controlador;

public class CarroP09 extends Thread{
  Controlador control;
  String nome;
  int cont = 0;

  public CarroP09(String nome){
    this.nome = nome;
  }//Fim construtor carroP06

  //vermelho
  public void run(){
    while(true){
      control.down("sem1x2");
        if(cont == 1){
          control.nomeCurvaEsquerdaMais("carroP09",1,-1);
          control.posicaoOriginal(control.carroP09img);
        }//Fim if
        control.carroP09T1(); //regiao critica
        control.up("sem1x3");

      control.down("sem2x2e3x2");
        control.carroP09T2(); //regiao critica
        control.up("sem1x2");
        
      control.down("sem3x2desc");
      control.down("sem4x2");
        control.up("sem2x2e3x2");
        control.carroP09T3(); //regiao critica
      control.up("sem3x2desc");

      control.down("sem5x2");
        control.up("sem4x2");
        control.carroP09T3V2(); //regiao critica

      control.down("sem5x3e5x4");
        control.up("sem5x2");
        control.nomeCurvaDireita(this.nome);
        control.carroP09T4(); //regiao critica
      control.up("sem5x3e5x4");

      control.nomeCurvaEsquerdaMais(this.nome,1,1);
      control.carroP09T5(); //regiao nao critica
      
      control.down("sem3x4");
      control.down("sem1x5e2x5e3x5");
        control.carroP09T6(); //regiao critica
        control.carroP09T7(); //regiao critica
        control.up("sem3x4");

      control.down("sem1x4");
        control.nomeCurvaEsquerdaMenos("carroP09",1,-1);
        control.carroP09T8(); //regiao critica

      control.down("sem1x3");
        control.up("sem1x5e2x5e3x5");
        control.up("sem1x4");
        control.carroP09T9();

      cont = 1; //controle da curva
    }//Fim while
  }//Fim metodo run

  public void setControlador(Controlador c){
    control = c;
  } //fim do metodo setControlador
}//Fim classe CarroP06