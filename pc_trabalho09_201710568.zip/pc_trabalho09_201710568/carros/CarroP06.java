package carros;

import controlador.Controlador;

public class CarroP06 extends Thread{
  Controlador control;
  String nome;
  int cont = 0;

  public CarroP06(String nome){
    this.nome = nome;
  }//Fim construtor carroP06

  //amarelo
  public void run(){
    while(true){
      control.down("sem1x1e2x1");
        if(cont == 1){
          control.nomeCurvaEsquerdaMais("carroP06",1,-1);
        }//Fim if
        control.posicaoOriginal(control.carroP06img); 
        control.carroP06T1(); //regiao critica
      control.up("sem1x1e2x1");

      control.carroP06T2(); //regiao nao critica

      control.down("sem4x1e5x1");
        control.carroP06T3(); //regiao critica

      control.down("sem5x1");
        control.up("sem4x1e5x1");
        control.nomeCurvaDireita(this.nome);
        control.carroP06T4(); //regiao critica
      control.up("sem5x1");

      control.nomeCurvaEsquerdaMais(this.nome,1,1);
      control.carroP06T5(); //regiao nao critica

      control.down("sem3x2");
        control.carroP06T6(); //regiao critica
      control.up("sem3x2");

      control.carroP06T7(); //regiao nao critica
      control.nomeCurvaEsquerdaMenos(this.nome,-1,-1);
      control.carroP06T8(); //regiao nao critica

      control.down("sem1x2");
      control.down("sem2x2e3x2");
        control.nomeCurvaEsquerdaMais(this.nome,-1,1);
        control.carroP06T9(); //regiao critica
      control.up("sem1x2");

      control.down("sem3x2desc");
      control.down("sem4x2");
        control.up("sem2x2e3x2");
        control.carroP06T10(); //regiao critica
      control.up("sem3x2desc");

      control.down("sem5x2");
        control.up("sem4x2");
        control.carroP06T10V2(); //regiao critica

      control.down("sem5x3e5x4");
        control.up("sem5x2");
        control.nomeCurvaDireita(this.nome);
        control.carroP06T11(); //regiao critica

      control.down("sem5x5e5x5e4x5");
        control.up("sem5x3e5x4");
        control.carroP06T12(); //regiao critica

      control.down("sem3x5e2x5e1x5");
        control.up("sem5x5e5x5e4x5");
        control.carroP06T13(); //regiao critica

      control.down("sem1x5");
        control.up("sem3x5e2x5e1x5");
        control.carroP06T14(); //regiao critica

      control.down("sem3x4");
      control.down("sem1x5e2x5e3x5");
        control.up("sem1x5");
        control.carroP06T15(); //regiao critica
        control.carroP06T16(); //regiao critica
      control.up("sem1x5e2x5e3x5");
        control.carroP06T17(); //regiao nao critica
      control.up("sem3x4");

      

      control.down("sem4x3");
        control.carroP06T18(); //regiao critica

      control.down("sem3x3");
        control.up("sem4x3");
        control.carroP06T19(); //regiao critica

      control.down("sem2x3");
        control.up("sem3x3");
        control.carroP06T20(); //regiao critica
      control.up("sem2x3");

      control.carroP06T21(); //regiao nao critica

      control.down("sem1x3");
        control.carroP06T22(); //regiao critica

      control.down("sem1x2e1x1");
        control.up("sem1x3");
        control.carroP06T23(); //regiao critica
      control.up("sem1x2e1x1");
      cont = 1; //controle da curva
    }//Fim while
  }//Fim metodo run

  public void setControlador(Controlador c){
    control = c;
  } //fim do metodo setControlador
}//Fim classe CarroP06