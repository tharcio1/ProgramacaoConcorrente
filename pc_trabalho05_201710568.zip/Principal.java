import java.io.IOException;
import javafx.application.Application;
import static javafx.application.Application.launch;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.stage.Stage;
import controlador.InserirInicial;
import controlador.Personagem;

/* ***************************************************************
* Autor: Tharcio Thalles Almeida Silva
* Matricula: 201710568
* Inicio: 22/08/2018
* Ultima alteracao: 26/08/2018
* Nome: Produtor/Consumidor 
* Funcao: O programa ilustra o problema do produtor/consumidor e resolve a condicao de corrida atraves de semaforos
*************************************************************** */


public class Principal extends Application{
  
  public static Scene principal;
  
  @Override
  public void start(Stage primaryStage ) throws IOException{
    Parent fxmlprincipal = FXMLLoader.load(getClass().getResource("/telas/principal.fxml"));

    principal = new Scene(fxmlprincipal);

    primaryStage.setScene(principal);

    primaryStage.show();
    
    InserirInicial inicial = new InserirInicial();
  }//fim start

  public static void main(String args[]){
    launch(args);
  }//fim main
}//fim classe