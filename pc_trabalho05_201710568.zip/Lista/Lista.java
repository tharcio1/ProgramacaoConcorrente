public class Lista{
  No inicio;
  int cont;

  public void inserirInicio(Object elemento){
    cont = cont + 1;
    No novo = new No();
    novo.setElemento(elemento);
    novo.setProximo(inicio);
    inicio = novo;
  }

  public void inserir(Object elemento){
    cont = cont + 1;
    No novo = new No();
    novo.setElemento(elemento);
    novo.setProximo(null);
    if(inicio == null){
      inicio = novo;
    }//fim if
    else{
      No aux;
      aux = inicio;
      while(aux.getProximo() != null){
        aux = aux.getProximo();
      }
      aux.setProximo(novo);
    }
  }//fim inserir

  public No retirar(Object elemento){
    cont = cont - 1;
    No aux = pesquisar(elemento);
    No temp = inicio;
    if(temp == aux){
      inicio = temp.getProximo();
    }else{
      if(aux == null){
        return null;
      }//fim if
      while(temp.getProximo() != aux){
        temp = temp.getProximo();
      }//fim while
      temp.setProximo(aux.getProximo());
    }//fim else
    return aux;
  }//fim retirar

  public No pesquisar(Object elemento){
    No aux = inicio;
    do{
      if(aux.getElemento() == elemento){
        return aux;
      }
      aux = aux.getProximo();
    }while(aux != null);
     return null;
  }// fim pesquisar

  public boolean isEmpty(){
    return(inicio == null);
  }//fim isempty

  public void listar(){
    if(inicio == null){
      System.out.println("Lista vazia!");
    }else{
      No aux = inicio;
      System.out.println("Elementos da lista: ");
      while(aux != null){
        System.out.println(aux.getElemento());
        aux = aux.getProximo();
      }//fim while
    }//fim else
  }//fim listar

  public void esvaziar(){
    inicio = null;
  }// fim ezvaziar

  public int tamanho(){
    return cont;
  }//fim tamanho

}//fim classe