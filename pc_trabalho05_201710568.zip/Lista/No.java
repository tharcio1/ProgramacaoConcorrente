package controlador;

public class No{
  private Object elemento;
  private No proximo;

  public void setElemento(Object elemento){
    this.elemento = elemento;
  }

  public void setProximo(No proximo){
    this.proximo = proximo;
  }

  public Object getElemento(){
    return this.elemento;
  }

  public No getProximo(){
    return this.proximo;
  }
}