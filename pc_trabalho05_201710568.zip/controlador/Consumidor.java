package controlador;

/* ***************************************************************
* Autor: Tharcio Thalles Almeida Silva
* Matricula: 201710568
* Inicio: 22/08/2018
* Ultima alteracao: 26/08/2018
* Nome: Produtor/Consumidor 
* Funcao: O programa ilustra o problema do produtor/consumidor e resolve a condicao de corrida atraves de semaforos
*************************************************************** */

public class Consumidor extends Thread{
	Personagem p3;
/* ***************************************************************
* Metodo: run
* Funcao: da inicio a execucao da thread do consumidor
* Parametros: void
* Retorno: void
*************************************************************** */
  public void run(){
    try{
      while(true){
        Thread.sleep(2000);
        p3.planta();
      }//fim while
    }//fim try
    catch(InterruptedException e){
      e.printStackTrace();
    }//fim catch
  }// fim run
/* ***************************************************************
* Metodo: setControlador
* Funcao: recebe o controlador para fazer alteracoes na GUI
* Parametros: controlador do tipo personagem p
* Retorno: void
*************************************************************** */
  public void setControlador(Personagem p){
    p3 = p;
  }//fim do metodo setControlador
}//fim classe