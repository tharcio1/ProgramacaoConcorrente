package controlador;

/* ***************************************************************
* Autor: Tharcio Thalles Almeida Silva
* Matricula: 201710568
* Inicio: 22/08/2018
* Ultima alteracao: 26/08/2018
* Nome: Produtor/Consumidor 
* Funcao: O programa ilustra o problema do produtor/consumidor e resolve a condicao de corrida atraves de semaforos
*************************************************************** */

public class Mover extends Thread{
  
  public static Personagem p1 = new Personagem();
  public static Personagem p2 = new Personagem();
/* ***************************************************************
* Metodo: run
* Funcao: da inicio a execucao da thread e nesse caso chama os metodos direcao e direcao 2 para serem executados
* Parametros: void
* Retorno: void
*************************************************************** */
  public void run(){
    try{
      while(true){
        Thread.sleep(25);
        p1.direcao();
        p2.direcao2();
      }//fim while
    }//fim try
    catch(InterruptedException e){
      e.printStackTrace();
    }//fim catch
  }//fim run
/* ***************************************************************
* Metodo: setControlador
* Funcao: recebe o controlador para fazer alteracoes na GUI
* Parametros: controlador do tipo personagem p
* Retorno: void
*************************************************************** */
  public void setControlador(Personagem p){
    p1 = p;
    p2 = p;
  }//fim do metodo setControlador
}//fim classe