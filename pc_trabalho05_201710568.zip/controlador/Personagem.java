package controlador;

import java.io.IOException;
import javafx.application.Application;
import javafx.fxml.FXMLLoader;
import java.net.URL;
import java.util.ResourceBundle;
import javafx.fxml.Initializable;
import javafx.fxml.FXML;
import javafx.scene.image.ImageView;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import java.lang.Thread;
import javafx.event.ActionEvent;
import javafx.application.Platform;
import java.util.Random;
import javafx.scene.media.AudioClip;
import static controlador.Mover.p1;
import static controlador.Mover.p2;

/* ***************************************************************
* Autor: Tharcio Thalles Almeida Silva
* Matricula: 201710568
* Inicio: 22/08/2018
* Ultima alteracao: 26/08/2018
* Nome: Produtor/Consumidor 
* Funcao: O programa ilustra o problema do produtor/consumidor e resolve a condicao de corrida atraves de semaforos
*************************************************************** */

public class Personagem implements Initializable{
  @FXML ImageView personagem;
  @FXML ImageView personagem2;
  @FXML ImageView princesa;
  @FXML ImageView tub;
  @FXML ImageView luigicomemorando;
  @FXML ImageView mariocomemorando;
  @FXML ImageView lm;
  @FXML ImageView ml;
  @FXML Button iniciarjogo;
  @FXML Button pausarjogo;
  @FXML Button aumentarProd;
  @FXML Button diminuirProd;
  URL url2;
  AudioClip musica;
  
  public static Lista lista = new Lista();

  Mover mv ;
  Consumidor planta;
  
  public static int control = 0;

  Random random = new Random();

  public static void inserirP(Personagem p1,String ml){
    lista.inserir(p1);
    lista.inserir(ml);
  }//fim inserirP
  
  /* ***************************************************************
* Metodo: construtor
* Funcao: toda instancia da classe executa o que esta dentro do construtor
* Parametros: void
* Retorno: void
*************************************************************** */
  public Personagem(){
    iniciarjogo = new Button();
    tub = new ImageView();
    mv = new Mover();
    planta = new Consumidor();
    personagem = new ImageView();
    personagem2 = new ImageView();
    princesa = new ImageView();
    luigicomemorando = new ImageView();
    mariocomemorando = new ImageView();
    lm = new ImageView();
    ml = new ImageView();
    url2 = getClass().getClassLoader().getResource("sons/musica.mp3");
    musica = new AudioClip(url2.toExternalForm());
  }//fim construtor
  
  /* ***************************************************************
  * Metodo: initialize
  * Funcao: eh executado na inicializacao da GUI
  * Parametros: url do tipo URL e rb do tipo ResourceBundle
  * Retorno: void
  *************************************************************** */
  @Override
  public void initialize(URL url, ResourceBundle rb){
    mv.setControlador(this);
    planta.setControlador(this);
    mv.start();
    planta.start();
  }//fim initialize
  public static double posicaox; //variavel posicaox que sera usada para setar a posicaox do personagem
  public static double posicaoy; //variavel posicaoy que sera usada para setar a posicaox do personagem
  public static double posicaox2; //variavel posicaox que sera usada para setar a posicaox do personagem
  public static double posicaoy2; //variavel posicaoy que sera usada para setar a posicaox do personagem
  public static int velmario = 2; //velocidade do mario
  public static int velluigi = 3; //velocidade do luigi
  public static int ctrmario = 0; //semaforo do mario
  public static int ctrluigi = 0; //semaforo do luigi
  public static int ctrplanta= 0; //semaforo da planta
  public boolean iniciar = false; //variavel que controla se o iniciar foi clicado

  /* ***************************************************************
  * Metodo: aumentaProducao
  * Funcao: aumenta a quantidade de personagens produzidos
  * Parametros: void
  * Retorno: void
  *************************************************************** */
  @FXML 
  public void aumentarProducao(){
    control = 1; //autoriza a producao mudando o control para 1 tambem eh um semaforo
    produzirLuigi();
  }//fim aumentarProducao

  /* ***************************************************************
  * Metodo: diminuirProducao
  * Funcao: diminui a quantidade de personagens produzidos
  * Parametros: void
  * Retorno: void
  *************************************************************** */
  @FXML
  public void diminuirProducao(){
    control = 0; //nao permite a producao pois esta 0 tambem eh um semaforo
  }//fim diminuirProducao

  /* ***************************************************************
  * Metodo: iniciar
  * Funcao: da inicio a simulacao
  * Parametros: void
  * Retorno: void
  *************************************************************** */
  @FXML 
  public void iniciar(){
    ctrplanta = 1; //semaforo da planta
    mariocomemorando.setVisible(false); //elemento da interface que aparece quando o mario ganha
    luigicomemorando.setVisible(false); //elemento da interface que aparece quando o luigi ganha
    musica.play(); //a inicio a musica
    tub.setVisible(true); // faz a planta ficar visivel pois existe algo para consumir
    if(lista.isEmpty()){
      if(control == 1){ //verifica se o botao aumentar producao foi clicado
        produzirLuigi(); //chama o metodo que produz o luigi
      }//fim if
      else{
        personagem.setLayoutY(0); // muda a posicao do luigi para o cano
        personagem.setLayoutX(44); // muda a posicao do luigi para o cano
        ctrluigi = 0; // impede que o luigi se movimente
      }//fim else
      inserirP(p2,"m"); // o mario eh inserido novamente toda vez que inicia o jogo pois ele eh a producao comum
    }//fim if
    if(lista.pesquisar("l") != null){ // verifica se o luigi foi inserido na lista pois se nao foi ele nao pode se movimentar pois nao pode ser consumido
      ctrluigi = 1; //muda o controle do luigi para 1 pois ele existe na lista e pode ser consumido
      personagem.setVisible(true);// torna o luigi visivel
    }//fim if
    if(lista.pesquisar("m") != null){// verifica se o mario foi inserido na lista pois se nao foi ele nao pode se movimentar pois nao pode ser consumido
      ctrmario = 1; //muda o controle do mario para 1 pois ele existe na lista e pode ser consumido
      personagem2.setVisible(true);// torna o mario visivel
    }//fim if
    iniciar = true;
    iniciarjogo.setVisible(false);
    lm.setVisible(false);
    ml.setVisible(false);
  }//fim iniciar
  
  /* ***************************************************************
  * Metodo: pausar
  * Funcao: pausa a simulacao
  * Parametros: void
  * Retorno: void
  *************************************************************** */
  @FXML 
  public void pausar(){
    musica.stop(); //para a musica
    iniciarjogo.setVisible(true);// torna o botao de play visivel
    lm.setVisible(true);
    ml.setVisible(true);
    iniciar = false; // diz que o jogo nao esta iniciado
    ctrmario = 0; // muda o controle da variavel para que o personagem nao possa se movimentar
    ctrluigi = 0; // muda o controle da variavel para que o personagem nao possa se movimentar
    ctrplanta = 0; // muda o controle da variavel para que o personagem nao possa se movimentar
  }//fim pausar

  /* ***************************************************************
  * Metodo: produzirMario
  * Funcao: produz marios
  * Parametros: void
  * Retorno: void
  *************************************************************** */
  public void produzirMario(){
    if(ctrmario == 0 && iniciar == true){ // verifica se o mario ja esta morto para que possa ser produzido outro
      ctrplanta = 1; //muda o controle da planta para 1 pois existe algo para ser consumido
      tub.setVisible(true); //deixa a planta visivel
      inserirP(p2,"m");//insere o mario na lista
      posicaox2 = 44; 
      posicaoy2 = 20; 
      personagem2.setLayoutX(posicaox2); //coloca o mario no cano
      personagem2.setLayoutY(posicaoy2); //coloca o mario no cano
      ctrmario = 1; // muda a variavel de controle do mario para ele poder se movimentar
      personagem2.setVisible(true); //faz com que o mario fique visivel
    }//fim if
  }//fim produzirMario

  /* ***************************************************************
  * Metodo: produzirLuigi
  * Funcao: produz Luigis
  * Parametros: void
  * Retorno: void
  *************************************************************** */
  public void produzirLuigi(){
    if(ctrluigi == 0 && iniciar == true){ // verifica se o luigi ja esta morto para que possa ser produzido outro
      ctrplanta = 1; //muda o controle da planta para 1 pois existe algo para ser consumido
      tub.setVisible(true); //deixa a planta visivel
      inserirP(p1,"l"); //insere o luigi na lista
      posicaoy = 0;
      posicaox = 44;
      personagem.setLayoutX(posicaox); //coloca o luigi no cano
      personagem.setLayoutY(posicaoy); //coloca o luigi no cano
      ctrluigi = 1; // muda a variavel de controle do luigi para ele poder se movimentar
      personagem.setVisible(true); // torna o luigi visivel
    }//fim if
  }//fim produzir

  /* ***************************************************************
  * Metodo: acelerarMario
  * Funcao: aumenta a velocidade do mario
  * Parametros: event do tipo ActionEvent
  * Retorno: void
  *************************************************************** */
  @FXML
  public void acelerarMario(ActionEvent event){
    if(velmario < 8){
      velmario += 2;
    }//fim if
  }//fim acelerarMario

  /* ***************************************************************
  * Metodo: frearMario
  * Funcao: diminui a velocidade do mario
  * Parametros: event do tipo ActionEvent
  * Retorno: void
  *************************************************************** */
  @FXML
  public void frearMario(ActionEvent event){
    if(velmario > 2){
      velmario -= 2;
    }//fim if
  }//fim frearMario

  /* ***************************************************************
  * Metodo: acelerarLuigi
  * Funcao: aumenta a velocidade do luigi
  * Parametros: event do tipo ActionEvent
  * Retorno: void
  *************************************************************** */
  @FXML
  public void acelerarLuigi(ActionEvent event){
    if(velluigi < 8){
      velluigi += 2;
    }//fim if
  }//fim acelerarLuigi

  /* ***************************************************************
  * Metodo: frearLuigi
  * Funcao: diminui a velocidade do luigi
  * Parametros: event do tipo ActionEvent
  * Retorno: void
  *************************************************************** */
  @FXML 
  public void frearLuigi(ActionEvent event){
    if(velluigi > 2){
      velluigi -= 2;
    }//fim if
  }//fim frearluigi

  /* ***************************************************************
  * Metodo: andar
  * Funcao: seta a posicao dos personagens para que eles se movimentem
  * Parametros: xy do que simboliza x ou y do tipo string
  * Retorno: void
  *************************************************************** */
  public void andar(String xy){
    Platform.runLater(() -> {
      if(xy == "x" && ctrluigi == 1){
        posicaox += velmario;
        personagem.setLayoutX(posicaox);  
      }else if(xy == "y" && ctrluigi == 1){
        personagem.setLayoutX(44);
        posicaoy += 2;
        personagem.setLayoutY(posicaoy);  
      }// fim else if
      if(xy == "x2" && ctrmario == 1){
        posicaox2 += velluigi;
        personagem2.setLayoutX(posicaox2);
      }else if(xy == "y2" && ctrmario == 1){
        personagem2.setLayoutX(44);
        posicaoy2 += 3;
        personagem2.setLayoutY(posicaoy2);
      }//fim else if
    }); //fim runlatter
  }// fim andar

  /* ***************************************************************
  * Metodo: direcao
  * Funcao: controla a direcao que o luigi irah e produz o luigi tambem
  * Parametros: void
  * Retorno: void
  *************************************************************** */
  //produtor 1
  public void direcao(){
    posicaox = personagem.getLayoutX();
    posicaoy = personagem.getLayoutY();
    posicaox2 = personagem2.getLayoutX();
    posicaoy2 = personagem2.getLayoutY();
    double rotacao = personagem.getRotate(); //variavel rotacao que sera usada para setar a rotacao do personagem    
    
    if(control == 1 && ctrluigi == 0 && iniciar == true){
        produzirLuigi();
    }//fim if

    if(lista.isEmpty()){
      ctrplanta = 0;
      tub.setVisible(false);
    }//fim if
    
    /* ***************************************************************
    * Metodo: if
    * Funcao: verifica se a planta consumiu algum personagem
    * Parametros: posicoes x e y dos personagens e do consumidor
    * Retorno: void
    *************************************************************** */
    if(tub.getLayoutX() >= personagem.getLayoutX() - 25 && tub.getLayoutX() <= personagem.getLayoutX() + 25 && personagem.getLayoutY() >= 229.0 || tub.getLayoutX() >= personagem2.getLayoutX() - 25 && tub.getLayoutX() <= personagem2.getLayoutX() + 25 && personagem2.getLayoutY() >= 229.0){
      if(tub.getLayoutX() >= personagem.getLayoutX() - 25 && tub.getLayoutX() <= personagem.getLayoutX() + 25 && personagem.getLayoutY() >= 229.0){
        personagem.setVisible(false);
        lista.retirar(p1);//personagem consumido
        lista.retirar("l");//personagem consumido
        luigicomemorando.setVisible(false);
        ctrluigi = 0;
        personagem.setLayoutY(0);
        personagem.setLayoutX(44);
      }else if(tub.getLayoutX() >= personagem2.getLayoutX() - 25 && tub.getLayoutX() <= personagem2.getLayoutX() + 25 && personagem2.getLayoutY() >= 229.0){
        personagem2.setVisible(false);
        mariocomemorando.setVisible(false);
        lista.retirar(p2);//personagem consumido
        lista.retirar("m");
        ctrmario = 0;
        personagem2.setLayoutY(16);
      }//fim else if
    }//fim if
    
    // verifica se o luigi atingiu a princesa
    if(personagem.getLayoutX() >= 740){
      luigicomemorando.setVisible(true);
      tub.setVisible(false);
      personagem2.setLayoutX(44);
      personagem2.setLayoutY(20);
      personagem.setLayoutX(44);
      personagem.setLayoutY(0);
      ctrluigi = 0;
      inserirP(p2,"m");
      pausar();
    }//fim if
    if(personagem.getLayoutY() < 229.0){
      andar("y");
    }//fim if
    else if(personagem.getLayoutY() >= 188.0 && personagem.getLayoutX() < 780.0){
      andar("x");
    }//fim else if
  }//fim direcao
  
  /* ***************************************************************
  * Metodo: direcao2
  * Funcao: controla a direcao que o mario irah e produz o mario tambem
  * Parametros: void
  * Retorno: void
  *************************************************************** */
  //produtor 2
  public void direcao2(){
    if(ctrmario == 0 && iniciar == true){
      produzirMario();
    }//fim if

    /* ***************************************************************
    * Metodo: if
    * Funcao: verifica se a planta consumiu algum personagem
    * Parametros: posicoes x e y dos personagens e do consumidor
    * Retorno: void
    *************************************************************** */
    if(tub.getLayoutX() >= personagem.getLayoutX() - 25 && tub.getLayoutX() <= personagem.getLayoutX() + 25 && personagem.getLayoutY() >= 229.0 || tub.getLayoutX() >= personagem2.getLayoutX() - 25 && tub.getLayoutX() <= personagem2.getLayoutX() + 25 && personagem2.getLayoutY() >= 229.0){
      if(tub.getLayoutX() >= personagem.getLayoutX() - 25 && tub.getLayoutX() <= personagem.getLayoutX() + 25 && personagem.getLayoutY() >= 229.0){
        personagem.setVisible(false);
        luigicomemorando.setVisible(false);
        lista.retirar(p1);//personagem consumido
        lista.retirar("l");
        ctrluigi = 0;
        personagem.setLayoutY(0);
        personagem.setLayoutX(44);
      }else if(tub.getLayoutX() >= personagem2.getLayoutX() - 25 && tub.getLayoutX() <= personagem2.getLayoutX() + 25 && personagem2.getLayoutY() >= 229.0){
        personagem2.setVisible(false);
        mariocomemorando.setVisible(false);
        lista.retirar(p2);
        lista.retirar("m");
        ctrmario = 0;
        personagem2.setLayoutY(16);
      }//fim else if
    }//fim if
    // verifica se o mario atingiu a princesa
    if(personagem2.getLayoutX() >= 740){
      mariocomemorando.setVisible(true);
      tub.setVisible(false);
      personagem2.setLayoutX(44);
      personagem2.setLayoutY(20);
      personagem.setLayoutX(44);
      personagem.setLayoutY(0);
      if(control == 1 && ctrluigi == 0 && iniciar == true){
        produzirLuigi();
      }//fim if
      personagem.setLayoutY(0);
      personagem.setLayoutX(44);
      pausar();
    }//fim if
    if(personagem2.getLayoutY() < 229.0){
      andar("y2");
    }//fim if
    else if(personagem2.getLayoutY() >= 188.0 && personagem2.getLayoutX() <= 780.0){
      andar("x2");
    }//fim else if
  }//fim direcao2

  /* ***************************************************************
  * Metodo: planta
  * Funcao: controla a direcao que a planta irah e a coloca em espera se nao existir algo para ser consumido
  * Parametros: void
  * Retorno: void
  *************************************************************** */
  //consumidor
  public void planta(){
    Platform.runLater(() -> {
      double posicaoxt = personagem.getLayoutX(); //variavel posicaox que sera usada para setar a posicaox do personagem
      double posicaoyt = personagem.getLayoutY(); //variavel posicaoy que sera usada para setar a posicaox do personagem
      double rotacao = personagem.getRotate(); //variavel rotacao que sera usada para setar a rotacao do personagem
      
      /* ***************************************************************
      * Metodo: if
      * Funcao: verifica se a planta consumiu algum personagem
      * Parametros: posicoes x e y dos personagens e do consumidor
      * Retorno: void
      *************************************************************** */
      if(tub.getLayoutX() >= personagem.getLayoutX() - 25 && tub.getLayoutX() <= personagem.getLayoutX() + 25 && personagem.getLayoutY() >= 229.0 || tub.getLayoutX() >= personagem2.getLayoutX() - 25 && tub.getLayoutX() <= personagem2.getLayoutX() + 25 && personagem2.getLayoutY() >= 229.0){
        if(tub.getLayoutX() >= personagem.getLayoutX() - 25 && tub.getLayoutX() <= personagem.getLayoutX() + 25 && personagem.getLayoutY() >= 229.0){
          personagem.setVisible(false);
          luigicomemorando.setVisible(false);
          lista.retirar(p1);//personagem consumido
          lista.retirar("l");
          ctrluigi = 0;
          personagem.setLayoutY(0);
          personagem.setLayoutX(44);
        }else if(tub.getLayoutX() >= personagem2.getLayoutX() - 25 && tub.getLayoutX() <= personagem2.getLayoutX() + 25 && personagem2.getLayoutY() >= 229.0){
          personagem2.setVisible(false);
          mariocomemorando.setVisible(false);
          lista.retirar(p2);
          lista.retirar("m");
          ctrmario = 0;
          personagem2.setLayoutY(16);
        }//fim else if
      }//fim if
      if(ctrplanta == 1){
        posicaoxt = random.nextInt(600);
        tub.setLayoutX(posicaoxt);
      }
      if(lista.isEmpty()){
        //se a lista estiver vazia faz com que a planta nao consuma mais e vai para o estado de espera
        ctrplanta = 0;
        tub.setVisible(false);
      }//fim if
    }); //fim runlatter
  }//fim planta
}//fim classe