package controlador;

import static controlador.Mover.p1;
import static controlador.Mover.p2;
import static controlador.Personagem.lista;

/* ***************************************************************
* Autor: Tharcio Thalles Almeida Silva
* Matricula: 201710568
* Inicio: 22/08/2018
* Ultima alteracao: 26/08/2018
* Nome: Produtor/Consumidor 
* Funcao: O programa ilustra o problema do produtor/consumidor e resolve a condicao de corrida atraves de semaforos
*************************************************************** */

public class InserirInicial extends Thread{
  /* ***************************************************************
* Metodo: construtor
* Funcao: toda instancia da classe executa o que esta dentro do construtor nesse caso a thread se auto inicia
* Parametros: void
* Retorno: void
*************************************************************** */
  public InserirInicial(){
    start();
  }
  /* ***************************************************************
* Metodo: run
* Funcao: da inicio a execucao da thread e nesse caso insere o mario
* Parametros: void
* Retorno: void
*************************************************************** */
  public void run(){
    p2.inserirP(p2,"m"); //inserindo personagens
  }//fim run
}//fim classe