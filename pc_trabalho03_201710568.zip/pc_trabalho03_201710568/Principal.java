import threads.Pai;

/* ***************************************************************
* Autor: Tharcio Thalles Almeida Silva
* Matricula: 201710568
* Inicio: 22/07/2018
* Ultima alteracao: 28/07/2018
* Nome: Arvore genealogica com Thread
* Funcao: O programa utiliza de Threads para inicializar outras Threads e executar concorrentemente as classes e  simula uma arvore genealogica utilizando tambem do sleep para simular o tempo
*************************************************************** */

public class Principal{
	public static void main(String[] args){
		Pai pai = new Pai();
		pai.start();
	}
}