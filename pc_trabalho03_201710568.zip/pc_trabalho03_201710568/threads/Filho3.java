package threads;

import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JButton;
import javax.swing.JTextField;
import java.awt.Color;
import javax.swing.ImageIcon;
import java.awt.FlowLayout;
import java.lang.Thread;
import static threads.Pai.j1;
import static threads.Pai.pn1;
import static threads.Pai.telaBranca;

/* ***************************************************************
* Autor: Tharcio Thalles Almeida Silva
* Matricula: 201710568
* Inicio: 22/07/2018
* Ultima alteracao: 28/07/2018
* Nome: Arvore genealogica com Thread
* Funcao: O programa utiliza de Threads para inicializar outras Threads e executar concorrentemente as classes e  simula uma arvore genealogica utilizando tambem do sleep para simular o tempo
*************************************************************** */

public class Filho3 extends Thread {
	
	public static ImageIcon f3;	

	public static JLabel filho3;	

	public Filho3(){

	}

	public void run(){
		try{
			System.out.println("O terceiro filho nasceu!"); //pai tem 32 anos

			f3 = new ImageIcon(getClass().getResource("/imagens/filhotresnasce.png"));
			filho3 = new JLabel(f3);
			pn1.add(filho3);
			filho3.setBounds(591,155, 144, 117);
			j1.repaint();

			Thread.sleep(5000); //5

			f3 = new ImageIcon(getClass().getResource("/imagens/filhotres5anos.png"));
			filho3.setIcon(f3);
			filho3.setBounds(591,155, 144, 117);
			j1.repaint();

			Thread.sleep(5000); // 10

			f3 = new ImageIcon(getClass().getResource("/imagens/filhotres10anos.png"));
			filho3.setIcon(f3);
			filho3.setBounds(591,155, 144, 117);
			j1.repaint();

			Thread.sleep(10000); //20

			f3 = new ImageIcon(getClass().getResource("/imagens/filhotres20anos.png"));
			filho3.setIcon(f3);
			filho3.setBounds(591,155, 144, 117);
			j1.repaint();

			Thread.sleep(10000); // 30

			f3 = new ImageIcon(getClass().getResource("/imagens/filhotres30anos.png"));
			filho3.setIcon(f3);
			filho3.setBounds(591,155, 144, 117);
			j1.repaint();

			Thread.sleep(10000); // 40

			f3 = new ImageIcon(getClass().getResource("/imagens/filhotres40anos.png"));
			filho3.setIcon(f3);
			filho3.setBounds(591,155, 144, 117);
			j1.repaint();

			Thread.sleep(8000); // 48

			f3 = new ImageIcon(getClass().getResource("/imagens/filhotres50anos.png"));
			filho3.setIcon(f3);
			filho3.setBounds(591,155, 144, 117);
			j1.repaint();

			Thread.sleep(4500); // 52 e meio

			ImageIcon morte = new ImageIcon(getClass().getResource("/imagens/morte4.gif"));
			JLabel morte1 = new JLabel(morte);
			pn1.add(morte1);
			morte1.setBounds(673,154, 231, 169);
			j1.repaint();
			Thread.sleep(2500); // 55
			morte1.setBounds(673,154, 0, 0);
			j1.repaint();

			f3 = new ImageIcon(getClass().getResource("/imagens/caixaopai4.png"));
	    filho3.setIcon(f3);
	    filho3.setBounds(591,155, 144, 117);
	    j1.repaint();

			System.out.println("O terceiro filho morreu!");
		} catch(InterruptedException e){
        	e.printStackTrace();
    	}
	
	}

}