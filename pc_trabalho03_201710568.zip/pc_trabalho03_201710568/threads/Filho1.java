package threads;

import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JButton;
import javax.swing.JTextField;
import java.awt.Color;
import javax.swing.ImageIcon;
import java.awt.FlowLayout;
import java.lang.Thread;
import static threads.Pai.j1;
import static threads.Pai.pn1;
import static threads.Pai.telaBranca;
import static threads.Filho2.filho2;
import static threads.Filho2.f2;
/* ***************************************************************
* Autor: Tharcio Thalles Almeida Silva
* Matricula: 201710568
* Inicio: 22/07/2018
* Ultima alteracao: 28/07/2018
* Nome: Arvore genealogica com Thread
* Funcao: O programa utiliza de Threads para inicializar outras Threads e executar concorrentemente as classes e  simula uma arvore genealogica utilizando tambem do sleep para simular o tempo
*************************************************************** */

public class Filho1 extends Thread{
	public Filho1(){
		
	}

	public void run(){
		try{
			ImageIcon f1 = new ImageIcon(getClass().getResource("/imagens/filhoumnasce.png"));
			JLabel filho1 = new JLabel(f1);
			pn1.add(filho1);
			filho1.setBounds(111,155, 144, 117);
			j1.repaint();

			System.out.println("O primeiro filho nasceu!");
			
			Thread.sleep(3000);

			f1 = new ImageIcon(getClass().getResource("/imagens/filhoum5anos.png"));
			filho1.setIcon(f1);
			filho1.setBounds(111,155, 144, 117);
			j1.repaint();

			Thread.sleep(5000);

			f1 = new ImageIcon(getClass().getResource("/imagens/filhoum10anos.png"));
			filho1.setIcon(f1);
			filho1.setBounds(111,155, 144, 117);
			j1.repaint();

			Thread.sleep(4000);
			
			f1 = new ImageIcon(getClass().getResource("/imagens/filhoum15anos.png"));
			filho1.setIcon(f1);
			filho1.setBounds(111,155, 144, 117);
			j1.repaint();

			Thread.sleep(4000);

			Neto1 neto1 = new Neto1();
			neto1.start();

			Thread.sleep(6000);

			f1 = new ImageIcon(getClass().getResource("/imagens/filhoum20anos.png"));
			filho1.setIcon(f1);
			filho1.setBounds(111,155, 144, 117);
			j1.repaint();
			
			Thread.sleep(9000);

			f1 = new ImageIcon(getClass().getResource("/imagens/filhoum30anos.png"));
			filho1.setIcon(f1);
			filho1.setBounds(111,155, 144, 117);
			j1.repaint();

			Thread.sleep(7000);

			f1 = new ImageIcon(getClass().getResource("/imagens/filhoum40anos.png"));
			filho1.setIcon(f1);
			filho1.setBounds(111,155, 144, 117);
			j1.repaint();

			Thread.sleep(10000);

			f1 = new ImageIcon(getClass().getResource("/imagens/filhoum50anos.png"));
			filho1.setIcon(f1);
			filho1.setBounds(111,155, 144, 117);
			j1.repaint();

			Thread.sleep(10500);

			ImageIcon morte = new ImageIcon(getClass().getResource("/imagens/morte2.gif"));
			JLabel morte1 = new JLabel(morte);
			pn1.add(morte1);
			morte1.setBounds(183,154, 231, 169);
			j1.repaint();
			Thread.sleep(2500);
			morte1.setBounds(183,154, 0, 0);
			j1.repaint();


			f1 = new ImageIcon(getClass().getResource("/imagens/caixaopai2.png"));
		    filho1.setIcon(f1);
		    filho1.setBounds(111,155, 144, 117);
		    j1.repaint();
			
			System.out.println("O primeiro filho morreu!");

		}catch(InterruptedException e){
        	e.printStackTrace();
    	}//fim do metodo catch
	

	}




}