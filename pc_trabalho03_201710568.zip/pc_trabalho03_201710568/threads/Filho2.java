package threads;

import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JButton;
import javax.swing.JTextField;
import java.awt.Color;
import javax.swing.ImageIcon;
import java.awt.FlowLayout;
import java.lang.Thread;
import static threads.Pai.j1;
import static threads.Pai.pn1;
import static threads.Pai.telaBranca;
import static threads.Filho3.filho3;
import static threads.Filho3.f3;

/* ***************************************************************
* Autor: Tharcio Thalles Almeida Silva
* Matricula: 201710568
* Inicio: 22/07/2018
* Ultima alteracao: 28/07/2018
* Nome: Arvore genealogica com Thread
* Funcao: O programa utiliza de Threads para inicializar outras Threads e executar concorrentemente as classes e  simula uma arvore genealogica utilizando tambem do sleep para simular o tempo
*************************************************************** */

public class Filho2 extends Thread{
	
	public static ImageIcon f2;	

	public static JLabel filho2;

	public Filho2(){

	}

	public void run(){
		try{	

			System.out.println("O segundo filho nasceu!");
			
			f2 = new ImageIcon(getClass().getResource("/imagens/filhodoisnasce.png"));
			filho2 = new JLabel(f2);
			pn1.add(filho2);
			filho2.setBounds(360,155, 144, 117);
			j1.repaint();
			
			Thread.sleep(4000); //4

			f2 = new ImageIcon(getClass().getResource("/imagens/filhodois4anos.png"));
			filho2.setIcon(f2);
			filho2.setBounds(360,155, 144, 117);
			j1.repaint();

			Thread.sleep(3000);// 7

			f2 = new ImageIcon(getClass().getResource("/imagens/filhodois7anos.png"));
			filho2.setIcon(f2);
			filho2.setBounds(360,155, 144, 117);
			j1.repaint();

			Thread.sleep(5000); // 12
			
			f2 = new ImageIcon(getClass().getResource("/imagens/filhodois12anos.png"));
			filho2.setIcon(f2);
			filho2.setBounds(360,155, 144, 117);
			j1.repaint();

			Thread.sleep(8000); // 20

			Neto2 neto2 = new Neto2();
			neto2.start();

			f2 = new ImageIcon(getClass().getResource("/imagens/filhodois20anos.png"));
			filho2.setIcon(f2);
			filho2.setBounds(360,155, 144, 117);
			j1.repaint();
			
			Thread.sleep(9000);// 29

			f2 = new ImageIcon(getClass().getResource("/imagens/filhodois30anos.png"));
			filho2.setIcon(f2);
			filho2.setBounds(360,155, 144, 117);
			j1.repaint();

			Thread.sleep(9000); // 38 

			f2 = new ImageIcon(getClass().getResource("/imagens/filhodois40anos.png"));
			filho2.setIcon(f2);
			filho2.setBounds(360,155, 144, 117);
			j1.repaint();

			Thread.sleep(9000); // 47

			f2 = new ImageIcon(getClass().getResource("/imagens/filhodois50anos.png"));
			filho2.setIcon(f2);
			filho2.setBounds(360,155, 144, 117);
			j1.repaint();

			Thread.sleep(5500); // 52 e meio

			ImageIcon morte = new ImageIcon(getClass().getResource("/imagens/morte3.gif"));
			JLabel morte1 = new JLabel(morte);
			pn1.add(morte1);
			morte1.setBounds(432,154, 231, 169);
			j1.repaint();
			Thread.sleep(2500); // 55
			morte1.setBounds(432,154, 0, 0);
			j1.repaint();

			f2 = new ImageIcon(getClass().getResource("/imagens/caixaopai3.png"));
	    filho2.setIcon(f2);
	    filho2.setBounds(360,155, 144, 117);
	    j1.repaint();

			System.out.println("O segundo filho morreu!");

		}catch(InterruptedException e){
        	e.printStackTrace();
    	}// fim do metodo catch

	
	}


}