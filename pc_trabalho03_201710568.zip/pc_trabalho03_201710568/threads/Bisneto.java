package threads;

import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JButton;
import javax.swing.JTextField;
import java.awt.Color;
import javax.swing.ImageIcon;
import java.awt.FlowLayout;
import java.lang.Thread;
import static threads.Pai.j1;
import static threads.Pai.pn1;
import static threads.Pai.telaBranca;
/* ***************************************************************
* Autor: Tharcio Thalles Almeida Silva
* Matricula: 201710568
* Inicio: 22/07/2018
* Ultima alteracao: 28/07/2018
* Nome: Arvore genealogica com Thread
* Funcao: O programa utiliza de Threads para inicializar outras Threads e executar concorrentemente as classes e  simula uma arvore genealogica utilizando tambem do sleep para simular o tempo
*************************************************************** */

public class Bisneto extends Thread{
	public Bisneto(){

	}

	public void run(){
		try{
			System.out.println("O Bisneto(filho do neto1) nasceu!");

			ImageIcon bisNto = new ImageIcon(getClass().getResource("/imagens/bisnetonasce.png"));
			JLabel bisNeto = new JLabel(bisNto);
			pn1.add(bisNeto);
			bisNeto.setBounds(111, 495, 144, 117);
			j1.repaint();

			Thread.sleep(3000);// 3

			bisNto = new ImageIcon(getClass().getResource("/imagens/bisneto3anos.png"));
			bisNeto.setIcon(bisNto);
			bisNeto.setBounds(111, 495, 144, 117);
			j1.repaint();

			Thread.sleep(3000); // 6

			bisNto = new ImageIcon(getClass().getResource("/imagens/bisneto6anos.png"));
			bisNeto.setIcon(bisNto);
			bisNeto.setBounds(111, 495, 144, 117);
			j1.repaint();

			Thread.sleep(3000); // 9

			bisNto = new ImageIcon(getClass().getResource("/imagens/bisneto9anos.png"));
			bisNeto.setIcon(bisNto);
			bisNeto.setBounds(111, 495, 144, 117);
			j1.repaint();

			Thread.sleep(500); // 9 e meio

			ImageIcon morte = new ImageIcon(getClass().getResource("/imagens/morte7.gif"));
			JLabel morte1 = new JLabel(morte);
			pn1.add(morte1);
			morte1.setBounds(183, 494, 231, 169);
			j1.repaint();
			Thread.sleep(2500); // 12
			morte1.setBounds(183, 494, 0, 0);
			j1.repaint();

			bisNto = new ImageIcon(getClass().getResource("/imagens/caixaopai7.png"));
	    bisNeto.setIcon(bisNto);
	    bisNeto.setBounds(111, 495, 144, 117);
	    j1.repaint();

			System.out.println("O Bisneto(filho do neto1) morreu!");
		} catch(InterruptedException e){
        	e.printStackTrace();
    	}// fim do metodo catch
	
	}

}