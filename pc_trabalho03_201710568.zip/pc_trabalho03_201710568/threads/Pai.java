package threads;

import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JButton;
import javax.swing.JTextField;
import java.awt.Color;
import javax.swing.ImageIcon;
import java.awt.FlowLayout;
import java.lang.Thread;
import javax.swing.JPanel;

/* ***************************************************************
* Autor: Tharcio Thalles Almeida Silva
* Matricula: 201710568
* Inicio: 22/07/2018
* Ultima alteracao: 28/07/2018
* Nome: Arvore genealogica com Thread
* Funcao: O programa utiliza de Threads para inicializar outras Threads e executar concorrentemente as classes e  simula uma arvore genealogica utilizando tambem do sleep para simular o tempo
*************************************************************** */


public class Pai extends Thread {
	
	public static JFrame j1 = new JFrame();
	public static JPanel pn1 = new JPanel();
	public static ImageIcon telaBranca;
	public static JLabel telaBr;	

	public void run(){
	    try{
		    j1.setSize(871, 680);
		    pn1.setSize(871, 680);

		    j1.add(pn1);
		    j1.setTitle("Arvore Genealogica");

		    ImageIcon pai = new ImageIcon(getClass().getResource("/imagens/painasce.png"));

		    JLabel paiNasce = new JLabel(pai); 

		    pn1.add(paiNasce);
		    paiNasce.setBounds(360, 14, 144, 117);

		    pn1.setBackground(Color.WHITE);

		    j1.setVisible(true);

		    j1.setResizable(false);

	      System.out.println("O pai nasceu!");

	      Thread.sleep(7000); // pai com 7 anos

	      pai = new ImageIcon(getClass().getResource("/imagens/pai5anos.png"));
	      paiNasce.setIcon(pai);
	      paiNasce.setBounds(360, 14, 144, 117);
	      j1.repaint();

	      Thread.sleep(7000); // pai com 14 anos

	      pai = new ImageIcon(getClass().getResource("/imagens/pai10anos.png"));
	      paiNasce.setIcon(pai);
	      paiNasce.setBounds(360, 14, 144, 117);
	      j1.repaint();
	      
	      Thread.sleep(7000);// pai com 21 anos

	      pai = new ImageIcon(getClass().getResource("/imagens/pai20anos.png"));
	      paiNasce.setIcon(pai);
	      paiNasce.setBounds(360, 14, 144, 117);
	      j1.repaint();

	      Thread.sleep(1000); //pai com 22 anos 

	      Filho1 filho1 = new Filho1();
	      filho1.start();
	      Thread.sleep(3000); // pai com 25 anos
	      Filho2 filho2 = new Filho2();
	      filho2.start();
	      sleep(7000); // pai com 32 anos
	      Filho3 filho3 = new Filho3();
	      filho3.start();

	      Thread.sleep(20000); // pai com 52 anos

	      pai = new ImageIcon(getClass().getResource("/imagens/pai30anos.png"));
	      paiNasce.setIcon(pai);
	      paiNasce.setBounds(360, 14, 144, 117);
	      j1.repaint();

	      Thread.sleep(19000); //pai com 71 anos

	      pai = new ImageIcon(getClass().getResource("/imagens/pai40anos.png"));
	      paiNasce.setIcon(pai);
	      paiNasce.setBounds(360, 14, 144, 117);
	      j1.repaint();

	      Thread.sleep(11000);// pai com 82 anos 

	      pai = new ImageIcon(getClass().getResource("/imagens/pai50anos.png"));
	      paiNasce.setIcon(pai);
	      paiNasce.setBounds(360, 14, 144, 117);
	      j1.repaint();

	      Thread.sleep(5500);// pai com 87 e meio

	      ImageIcon morte = new ImageIcon(getClass().getResource("/imagens/morte1.gif"));
				telaBranca = new ImageIcon(getClass().getResource("/imagens/telabranca.png"));
				JLabel morte1 = new JLabel(morte);
				pn1.add(morte1);
				morte1.setBounds(438, 13, 231, 169);
				j1.repaint();
				Thread.sleep(2500);
				morte1.setBounds(438, 13, 0, 0);
				j1.repaint();

				System.out.println("Pai morre aos 90 anos!");  

	      pai = new ImageIcon(getClass().getResource("/imagens/caixaopai1.png"));
	      paiNasce.setIcon(pai);
	      paiNasce.setBounds(360, 14, 144, 117);
	      j1.repaint();

    } catch(InterruptedException e){
        e.printStackTrace();
    }

   
  }
}