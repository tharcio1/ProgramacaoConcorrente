package threads;

import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JButton;
import javax.swing.JTextField;
import java.awt.Color;
import javax.swing.ImageIcon;
import java.awt.FlowLayout;
import java.lang.Thread;
import static threads.Pai.j1;
import static threads.Pai.pn1;
import static threads.Neto2.neto2;
import static threads.Neto2.nt2;
import static threads.Pai.telaBranca;
import static threads.Pai.telaBr;

/* ***************************************************************
* Autor: Tharcio Thalles Almeida Silva
* Matricula: 201710568
* Inicio: 22/07/2018
* Ultima alteracao: 28/07/2018
* Nome: Arvore genealogica com Thread
* Funcao: O programa utiliza de Threads para inicializar outras Threads e executar concorrentemente as classes e  simula uma arvore genealogica utilizando tambem do sleep para simular o tempo
*************************************************************** */

public class Neto1 extends Thread{
	public Neto1(){

	}

	public void run(){
		try{	
			System.out.println("Primeiro neto(filho do filho 1) nasceu!");

			ImageIcon nt1 = new ImageIcon(getClass().getResource("/imagens/netoumnasce.png"));
			JLabel neto1 = new JLabel(nt1);
			pn1.add(neto1);
			neto1.setBounds(111,332, 144, 117);
			j1.repaint();

			Thread.sleep(5000); // 5

			nt1 = new ImageIcon(getClass().getResource("/imagens/netoum5anos.png"));
			neto1.setIcon(nt1);
			neto1.setBounds(111,332, 144, 117);
			j1.repaint();

			Thread.sleep(5000); // 10

			nt1 = new ImageIcon(getClass().getResource("/imagens/netoum10anos.png"));
			neto1.setIcon(nt1);
			neto1.setBounds(111,332, 144, 117);
			j1.repaint();

			Thread.sleep(5000); // 15

			nt1 = new ImageIcon(getClass().getResource("/imagens/netoum15anos.png"));
			neto1.setIcon(nt1);
			neto1.setBounds(111,332, 144, 117);
			j1.repaint();

			Thread.sleep(5000); // 20

			nt1 = new ImageIcon(getClass().getResource("/imagens/netoum20anos.png"));
			neto1.setIcon(nt1);
			neto1.setBounds(111,332, 144, 117);
			j1.repaint();

			Thread.sleep(4000); // 24

			nt1 = new ImageIcon(getClass().getResource("/imagens/netoum25anos.png"));
			neto1.setIcon(nt1);
			neto1.setBounds(111,332, 144, 117);
			j1.repaint();

			Thread.sleep(4000); // 28

			nt1 = new ImageIcon(getClass().getResource("/imagens/netoum35anos.png"));
			neto1.setIcon(nt1);
			neto1.setBounds(111,332, 144, 117);
			j1.repaint();

			Thread.sleep(2000); // 30

			Bisneto bisneto = new Bisneto();
			bisneto.start();

			Thread.sleep(2500); // 32 e meio

			ImageIcon morte = new ImageIcon(getClass().getResource("/imagens/morte5.gif"));
			JLabel morte1 = new JLabel(morte);
			pn1.add(morte1);
			morte1.setBounds(183, 331, 231, 169);
			j1.repaint();
			Thread.sleep(2500); // 35
			morte1.setBounds(183, 331, 0, 0);
			j1.repaint();

			nt1 = new ImageIcon(getClass().getResource("/imagens/caixaopai5.png"));
	    neto1.setIcon(nt1);
	    neto1.setBounds(111,332, 144, 117);
	    j1.repaint();

			System.out.println("Primeiro neto(filho do filho 1) Morreu!");
			
		} catch(InterruptedException e){
        	e.printStackTrace();
    	}
	
	}

}